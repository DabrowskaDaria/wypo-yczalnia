package com.rental.rentalapplication.DTO;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public class PasswordDto {
	
	@NotEmpty(message="Pole nie może być puste")
	@Size(min=8, message="Hasło musi mieć co najmniej 8 znaków")
	@Pattern(regexp = "^(?=.*[A-Z])(?=.*\\d.*\\d)(?=.*[@#$%^&+=!])(?=.*[a-zA-Z]).{8,}$",message="Hasło nie spełnia zasad złożoności")
	private String newPassword;

	@NotEmpty(message="Pole nie może być puste")
	@Size(min=8, message="Hasło musi mieć co najmniej 8 znaków")
	@Pattern(regexp = "^(?=.*[A-Z])(?=.*\\d.*\\d)(?=.*[@#$%^&+=!])(?=.*[a-zA-Z]).{8,}$",message="Hasło nie spełnia zasad złożoności")
	private String repeatedPassword;

	public String getNewPassword() {
		return newPassword;
	}

	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}

	public String getRepeatedPassword() {
		return repeatedPassword;
	}

	public void setRepeatedPassword(String repeatedPassword) {
		this.repeatedPassword = repeatedPassword;
	}
	
}
