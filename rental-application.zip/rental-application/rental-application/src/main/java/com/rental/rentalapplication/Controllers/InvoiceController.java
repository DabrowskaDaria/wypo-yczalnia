package com.rental.rentalapplication.Controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.rental.rentalapplication.Models.Invoice;
import com.rental.rentalapplication.Repository.InvoiceRepository;

@Controller
public class InvoiceController {

	@Autowired
	InvoiceRepository invoiceRepo;
	
	@GetMapping("/showInvoices")
	public String showInvoices(Model model) {
		List<Invoice> invoices= invoiceRepo.findAll();
		model.addAttribute("invoices", invoices);
		return "/invoice/showInvoices";
	}
}
