package com.rental.rentalapplication.Controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.rental.rentalapplication.DTO.DeviceDto;
import com.rental.rentalapplication.Models.Category;

import com.rental.rentalapplication.Models.Connector;
import com.rental.rentalapplication.Models.Device;
import com.rental.rentalapplication.Services.CategoryManager;
import com.rental.rentalapplication.Services.ConnectorManager;
import com.rental.rentalapplication.Services.DeviceManager;

import jakarta.validation.Valid;

@Controller
@RequestMapping("/device")
public class DeviceController {
	@Autowired
	private DeviceManager deviceManager;
	
	@Autowired
	private CategoryManager categoryManager;
	
	@Autowired
	private ConnectorManager connectorManager;
	
	@GetMapping("/add")
	public String showcreateDevicePage(Model model) {
		List<Category> categories= categoryManager.showCategory();
		List<Connector> connectors=connectorManager.showConnectors();
	
		model.addAttribute("deviceDto", new DeviceDto() );
		model.addAttribute("categories", categories);
		model.addAttribute("connectors", connectors);
		
		return "device/addDevice";
	}
	
	@PostMapping("/add")
	public String addDevice(@ModelAttribute DeviceDto deviceDto,RedirectAttributes redirectAttributes){
		deviceManager.addDevice(deviceDto,redirectAttributes);
		//redirectAttributes.addFlashAttribute("info", "Dodano urządzenie");
		return "redirect:/device/add";
	}
	
	@GetMapping("/showDevices")
	public String showDevices(Model model) {
		List <Device> devices=deviceManager.showDevices();
		model.addAttribute("devices", devices);
		return "device/showDevices";
	}
	
	@PostMapping("/deleteDevice/{id}/delete")
	public String deleteDevice(@PathVariable("id") Integer id) {
		deviceManager.deleteDevice(id);
		return"redirect:/device/showDevices";
	}
	
	@GetMapping("/modify/{id}")
	public String showModifyDeviceForm(@PathVariable ("id") Integer id, Model model) {
		Device device=deviceManager.getDevice(id);
		model.addAttribute("device", device);
		model.addAttribute("deviceDto", new DeviceDto());
		return "device/modifyDevice";
	}
	
	@PostMapping("/modify/{id}")
	public String modifyDevice(@PathVariable Integer id,@Valid @ModelAttribute DeviceDto deviceDto,BindingResult bindingResult) {
		if (bindingResult.hasErrors()) {
            return "device/modifyDevice";
        }
		deviceManager.modify(deviceDto, id);
		return "redirect:/device/showDevices";
	}
	
}
