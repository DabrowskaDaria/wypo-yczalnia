package com.rental.rentalapplication.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.rental.rentalapplication.Models.Category;
import com.rental.rentalapplication.Models.Device;

@Repository
public interface DeviceRepository extends JpaRepository<Device, Integer> {
	List<Device> findByCategoryName(String category);
	
	List<Device> findByCategoryNameAndNameAndPriceAndDepositAndDescription(String category, String name, Integer price, Integer deposit,String description);
	
	Integer countByCategoryNameAndNameAndPriceAndDepositAndImageDisplayScreenSizeAndImageDisplayScreenResolutionAndImageDisplayRefreshRate(
			String category, String name, Integer price, Integer deposit,String screenSize,String screenResolution, Integer refreshRate);
	
	Integer countByCategoryNameAndNameAndPriceAndDepositAndComputerDisplayAndComputerProcessorAndComputerDriveAndComputerRamAndComputerGraphicsCardAndComputerOperatingSystem(
			String category, String name, Integer price, Integer deposit,String display, String processor, String drive, Integer ram, String graphicsCard, String operatingSystem);
	
	Integer countByCategoryNameAndNameAndPriceAndDepositAndComputerDisplayAndComputerProcessorAndComputerDriveAndComputerRamAndComputerOperatingSystem(
			String category, String name, Integer price, Integer deposit,String display, String processor, String drive, Integer ram, String operatingSystem);
	
	Integer countByCategoryNameAndNameAndPriceAndDepositAndAudioDeviceSpeakersPowerAndAudioDeviceNumberOfspeakers(String category, String name, Integer price, Integer deposit,String speakersPower,Integer numberOfspeakers);
	
	Integer countByCategoryNameAndNameAndPriceAndDepositAndImageDisplayMatrixTypeAndImageDisplayLampPowerAndImageDisplayScreenResolution(
			String category, String name, Integer price, Integer deposit,String matrixType,Integer lampPower, String screenResolution);
	
	Integer countByCategoryNameAndNameAndPriceAndDepositAndImageDisplayScreenFormatAndImageDisplayScreenSizeAndImageDisplayActiveSurface(
			String category, String name, Integer price, Integer deposit,String screenFormat, String screenSize, String activeSurface);
	
	Integer countByCategoryNameAndNameAndPriceAndDepositAndLightingLightingColorAndLightingPowerConsumptionAndLightingDeviceSizeAndLightingLampPower(
			String category, String name, Integer price, Integer deposit,String lightingColor, Integer powerConsumption,String deviceSize,Integer lampPower);
	
	Integer countByCategoryNameAndNameAndPriceAndDepositAndAudioDeviceHeadphoneTypeAndAudioDeviceMicrophoneAndAudioDeviceWirelessTransmissionAndAudioDeviceWorkingTime(
			String category, String name, Integer price, Integer deposit,String headphoneType,Boolean microphone, Boolean wirelessTransmission, Integer workingTime);
	
	Integer countByCategoryNameAndNameAndPriceAndDepositAndCameraResolutionAndCameraImageStabilizationAndCameraOpticalZoom(
			String category, String name, Integer price, Integer deposit, String resolution,Boolean imageStabilization,Boolean opticalZoom);
	
	Integer countByCategoryNameAndNameAndPriceAndDepositAndAudioDeviceMicrophoneTypeAndAudioDeviceFrequencyResponseAndAudioDeviceWirelessTransmission(
			String category, String name, Integer price, Integer deposit,String microphoneType,String frequencyResponse,Boolean wirelessTransmission);
}
