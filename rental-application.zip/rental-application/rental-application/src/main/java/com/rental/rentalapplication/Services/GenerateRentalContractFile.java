package com.rental.rentalapplication.Services;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aspose.pdf.Document;
import com.aspose.pdf.Page;
import com.aspose.pdf.TextFragment;
import com.rental.rentalapplication.Models.Device;
import com.rental.rentalapplication.Models.DeviceRental;
import com.rental.rentalapplication.Models.Rental;
import com.rental.rentalapplication.Repository.RentalRepository;

@Service
public class GenerateRentalContractFile {

	@Autowired
	private RentalRepository rentalRepo;
	
	public byte[] generateContract(Integer id) throws IOException{
		Rental rental=rentalRepo.findById(id).get();
		Document document = new Document();
		
		Page page=document.getPages().add();
		page.getParagraphs().add(new TextFragment("Umowa wypożyczenia"));
		if("Anulowane".equals(rental.getRentalStatus().getName())) {
			page.getParagraphs().add(new TextFragment("Wypożyczenie zostało anulowane"));
		}
		page.getParagraphs().add(new TextFragment("Data wypożyczenia: "+rental.getRentalStartDate()));
		page.getParagraphs().add(new TextFragment("Data zwrotu: "+rental.getRentalEndDate()));
		page.getParagraphs().add(new TextFragment("Metoda płatności: "+rental.getMethodOfPayment().getName()));
		page.getParagraphs().add(new TextFragment("Sposób dostawy: "+rental.getMethodOfReception().getName()));
		page.getParagraphs().add(new TextFragment("Dane wypożyczającego: "));
		if(rental.getUser().getCompany()==null) {
			page.getParagraphs().add(new TextFragment("Imię i nazwisko: "+rental.getUser().getPerson().getFirstName()+" "+rental.getUser().getPerson().getSurname()));
			page.getParagraphs().add(new TextFragment("Numer telefonu: "+rental.getUser().getPerson().getPhoneNumber()));
			page.getParagraphs().add(new TextFragment("Pesel: "+ rental.getUser().getPerson().getPesel()));
			page.getParagraphs().add(new TextFragment("Adres: "
					+rental.getUser().getPerson().getPlace()+" ul. "
					+rental.getUser().getPerson().getStreet()+ " "
					+rental.getUser().getPerson().getHouseNumber()+" "
					+rental.getUser().getPerson().getZipCode()));
			
		}else {
			
			page.getParagraphs().add(new TextFragment("Nazwa firmy: "+rental.getUser().getCompany().getName()));
			page.getParagraphs().add(new TextFragment("Nip: "+rental.getUser().getCompany().getCompanyNumber()));
			page.getParagraphs().add(new TextFragment("Adres: "
					+rental.getUser().getCompany().getPlace()+" "
					+rental.getUser().getCompany().getStreet()+ " "
					+rental.getUser().getCompany().getBuldingNumber()+" "
					+rental.getUser().getCompany().getZipCode()));
		}
		List<Device> devices=new ArrayList<Device>();
		for (DeviceRental  deviceRental: rental.getDeviceRentals()) {
			devices.add(deviceRental.getDevice());
		}
		page.getParagraphs().add(new TextFragment("Wypożyczone urządzenia: "));
		Integer i=1;
		for (Device device : devices) {
			page.getParagraphs().add(new TextFragment(i+" "+device.getName()+" "+device.getPrice()+" zł "+device.getDeposit()+" zł. "+device.getCategory().getName()));
			i++;
		}
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        document.save(outputStream);
        document.close();
        return outputStream.toByteArray();

	}
}
