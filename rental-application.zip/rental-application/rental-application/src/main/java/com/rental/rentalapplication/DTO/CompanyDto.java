package com.rental.rentalapplication.DTO;

import jakarta.validation.constraints.NotEmpty;

public class CompanyDto {
	@NotEmpty(message="Pole nie może być puste")
	private String place;
	
	@NotEmpty(message="Pole nie może być puste")
	private String street;
	
	@NotEmpty(message="Pole nie może być puste")
	private String zipCode;
	
	@NotEmpty(message="Pole nie może być puste")
	private String name;
	
	@NotEmpty(message="Pole nie może być puste")
	private String companyNumber;
	
	@NotEmpty(message="Pole nie może być puste")
	private String buldingNumber;

	public String getPlace() {
		return place;
	}

	public void setPlace(String place) {
		this.place = place;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCompanyNumber() {
		return companyNumber;
	}

	public void setCompanyNumber(String companyNumber) {
		this.companyNumber = companyNumber;
	}

	public String getBuldingNumber() {
		return buldingNumber;
	}

	public void setBuldingNumber(String buldingNumber) {
		this.buldingNumber = buldingNumber;
	}
}
