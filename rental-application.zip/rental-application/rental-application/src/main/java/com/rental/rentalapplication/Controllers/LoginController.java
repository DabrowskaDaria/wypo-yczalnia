package com.rental.rentalapplication.Controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;


@Controller
public class LoginController {
	@Autowired
	private com.rental.rentalapplication.Services.SecurityManager securityManager;
		
	@GetMapping("/login")
	public String showLoginForm(Model model) {
		return"/login/login";
	}

	@GetMapping("/logout")
	public String logout() {
		securityManager.logout();
		return"redirect:/";
	}
	
}
