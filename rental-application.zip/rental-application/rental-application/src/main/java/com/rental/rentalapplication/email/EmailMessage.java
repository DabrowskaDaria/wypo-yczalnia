package com.rental.rentalapplication.email;

import com.rental.rentalapplication.Models.User;

public abstract class EmailMessage {
	private User receiver;
	
	public abstract  String content();
	
	public abstract String subject();

	public EmailMessage(User receiver) {
		super();
		this.receiver = receiver;
	}

	public User getReceiver() {
		return receiver;
	}

	public void setReceiver(User receiver) {
		this.receiver = receiver;
	}
}
