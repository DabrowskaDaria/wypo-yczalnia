package com.rental.rentalapplication.email;

import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class EmailSender {
	
	private JavaMailSender javaMailSender;
	
	public EmailSender(JavaMailSender javaMailSender) {
		super();
		this.javaMailSender= javaMailSender;
	}
	
	public void send(EmailMessage emailMessage) {
		SimpleMailMessage message= new SimpleMailMessage();
		message.setTo(emailMessage.getReceiver().getEmail());
		message.setFrom("<D.Dabrowska@wit.edu.pl>");
		message.setSubject(emailMessage.subject());
		message.setText(emailMessage.content());
		javaMailSender.send(message);
	}
}
