package com.rental.rentalapplication.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;


@Configuration
@EnableWebSecurity
public class SecurityConfig {

	
	private UserDetailsService userDetailsService;

	public SecurityConfig(UserDetailsService userDetailsService) {
		super();
		this.userDetailsService = userDetailsService;
	}
	
	@Bean
	public static PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}
	
	@Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            
            .authorizeHttpRequests(authorize -> authorize
            	.requestMatchers("/css/**","/categories/**","/showDetails/{id}","/account/create","/changePassword","/login","/passwordRecovery","/resetPassword","/resetPasswordSuccessPage").permitAll()
            	.requestMatchers("/device/**","/user","/account/add","/changeStatus/{id}","/showRentals","/notReturned","/device/add","/showInvoices","/currentlyRentedDevices").hasAuthority("Administrator")
            	.requestMatchers("/homePageForUser","/showCart","/deleteDeviceFromCart/{id}","/addToCart/{id}","/device/**","/currentRentals","/historyRentals","/account/edit","/changePassword","/showFavouriteList","/addToFavouriteList/{id}","/deleteDevicefromFavouriteList/{id}").hasAuthority("Użytkownik")
                .requestMatchers("/showInvoices").hasAuthority("Pracownik")
            	.anyRequest().authenticated()
            )
            .formLogin(form -> form
            		.loginPage("/login")
            		.usernameParameter("email")
            		.passwordParameter("password")
            		.loginProcessingUrl("/login")
            		.defaultSuccessUrl("/homePageForUser")
            		.failureUrl("/login?error=true")
            		.permitAll()
            		)
            .logout(
            		logout -> logout
            		.logoutUrl("/logout")
            		.logoutSuccessUrl("/")
            		.invalidateHttpSession(true)
            		.permitAll()
            		);
            
        return http.build();
    }
	
	
	public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception{
		auth.userDetailsService(userDetailsService).passwordEncoder(passwordEncoder());
	}
	

}
