package com.rental.rentalapplication.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;

import com.rental.rentalapplication.Models.ImageDisplay;


@Repository
public interface ImageDisplayRepository extends JpaRepository<ImageDisplay, Integer> {
	List<ImageDisplay> findByScreenResolutionAndScreenSizeAndRefreshRate(String screenResolution,String screenSize,Integer refreshRate);
	List<ImageDisplay> findByMatrixTypeAndLampPowerAndScreenResolution(String matrixType,Integer lampPower,String screenResolution);
	List<ImageDisplay> findByScreenFormatAndScreenSizeAndActiveSurface(String screenFormat,String screenSize,String activeSurface);
}
