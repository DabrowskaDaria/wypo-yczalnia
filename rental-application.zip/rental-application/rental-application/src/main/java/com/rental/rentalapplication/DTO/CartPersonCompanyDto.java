package com.rental.rentalapplication.DTO;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public class CartPersonCompanyDto {
	
	
	@NotEmpty(message="Pole nie może być puste")
	private String firstName;
	
	@NotEmpty(message="Pole nie może być puste")
	private String surname;
	
	@NotEmpty(message="Pole nie może być puste")
	private String peselNumber;
	
	@NotEmpty(message="Pole nie może być puste")
	@Size(min=9, message="Za krótki numer telefonu")
	private String phoneNumber;
	
	@NotEmpty(message="Pole nie może być puste")
	private String place;
	
	@NotEmpty(message="Pole nie może być puste")
	
	private String street;
	
	@NotEmpty(message="Pole nie może być puste")
	private String houseNumber;
	
	@NotEmpty(message="Pole nie może być puste")
	private String zipCode;
	
	@NotEmpty(message="Pole nie może być puste")
	private String name;
	
	@NotEmpty(message="Pole nie może być puste")
	private String companyNumber;
	
	@NotEmpty(message="Pole nie może być puste")
	private String buldingNumber;

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	public String getPeselNumber() {
		return peselNumber;
	}

	public void setPeselNumber(String peselNumber) {
		this.peselNumber = peselNumber;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getPlace() {
		return place;
	}

	public void setPlace(String place) {
		this.place = place;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getHouseNumber() {
		return houseNumber;
	}

	public void setHouseNumber(String houseNumber) {
		this.houseNumber = houseNumber;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCompanyNumber() {
		return companyNumber;
	}

	public void setCompanyNumber(String companyNumber) {
		this.companyNumber = companyNumber;
	}

	public String getBuldingNumber() {
		return buldingNumber;
	}

	public void setBuldingNumber(String buldingNumber) {
		this.buldingNumber = buldingNumber;
	}
	
}
