package com.rental.rentalapplication;

import java.time.temporal.ChronoUnit;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.rental.rentalapplication.Models.DeviceCart;
import com.rental.rentalapplication.Models.DeviceRental;
import com.rental.rentalapplication.Models.Rental;
import com.rental.rentalapplication.Repository.CartRepository;

@Component
public class RentalCost {
	
	private Integer totalPrice=0;
	
	private Integer totalDeposit=0;
	
	public Integer calculateTotalDeposit(Rental rental) {
		for(DeviceRental deviceRental :  rental.getDeviceRentals()) {
			totalDeposit+=deviceRental.getDevice().getDeposit();
		}
		return totalDeposit;
	}
	
	public Integer calculateTotalPrice(Rental rental) {
		for(DeviceRental deviceRental :  rental.getDeviceRentals()) {
			Integer days=(int)ChronoUnit.DAYS.between(rental.getRentalStartDate(), rental.getRentalEndDate());
			totalPrice+=deviceRental.getDevice().getPrice()*days;
		}
		return totalPrice;
	}
	
	public Integer calculateCosts(Integer totalPrice, Integer totalDeposit) {
		return totalPrice+totalDeposit;
	}
		
}



