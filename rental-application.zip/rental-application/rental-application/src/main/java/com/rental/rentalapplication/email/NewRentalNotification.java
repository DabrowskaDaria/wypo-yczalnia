package com.rental.rentalapplication.email;

import com.rental.rentalapplication.Models.User;

public class NewRentalNotification extends EmailMessage {

	
	public NewRentalNotification(User receiver) {
		super(receiver);
	}

	@Override
	public String content() {
		return "Dokonano nowego wypożyczenia";
	}

	@Override
	public String subject() {
		
		return "Nowe wypożyczenie";
	}


	
}
