package com.rental.rentalapplication.email;

import com.rental.rentalapplication.Models.DeviceRental;
import com.rental.rentalapplication.Models.Rental;
import com.rental.rentalapplication.Models.User;

public class NewRentalNotification extends EmailMessage {

	private Rental rental; 
	public NewRentalNotification(User receiver,Rental rental) {
		super(receiver);
		this.rental=rental;
	}

	@Override
	public String content() {
		StringBuilder stringBuilder=new StringBuilder();
		stringBuilder.append("Dokonano nowego wypożyczenia.\nUrządzenia należy zwrócic dnia: ").append(rental.getRentalEndDate()).append("\n Wypożyczono: \n");
		
		for (DeviceRental deviceRental : rental.getDeviceRentals()) {
			
			stringBuilder.append("- ").append(deviceRental.getDevice().getName()).append(" ").append(deviceRental.getDevice().getPrice()).append("zł  ").append(deviceRental.getDevice().getDeposit()).append(" zł \n");
		}
		return stringBuilder.toString();
	}

	@Override
	public String subject() {
		
		return "Nowe wypożyczenie";
	}


	
}
