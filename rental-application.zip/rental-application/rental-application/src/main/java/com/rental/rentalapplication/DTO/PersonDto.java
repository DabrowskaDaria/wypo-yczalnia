package com.rental.rentalapplication.DTO;

import jakarta.validation.constraints.NotEmpty;

import jakarta.validation.constraints.Size;

public class PersonDto {
	
	
	@NotEmpty(message="Pole nie może być puste")
	private String firstName;
	
	@NotEmpty(message="Pole nie może być puste")
	private String surname;
	
	@NotEmpty(message="Pole nie może być puste")
	private String pesel;
	
	@NotEmpty(message="Pole nie może być puste")
	@Size(min=9, message="Za krótki numer telefonu")
	private String phoneNumber;
	
	@NotEmpty(message="Pole nie może być puste")
	private String place;
	
	@NotEmpty(message="Pole nie może być puste")
	
	private String street;
	
	@NotEmpty(message="Pole nie może być puste")
	private String houseNumber;
	
	@NotEmpty(message="Pole nie może być puste")
	private String zipCode;
	

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}


	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getPlace() {
		return place;
	}

	public void setPlace(String place) {
		this.place = place;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getHouseNumber() {
		return houseNumber;
	}

	public void setHouseNumber(String houseNumber) {
		this.houseNumber = houseNumber;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getPesel() {
		return pesel;
	}

	public void setPesel(String pesel) {
		this.pesel = pesel;
	}

}
