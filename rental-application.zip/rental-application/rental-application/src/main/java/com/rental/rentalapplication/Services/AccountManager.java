package com.rental.rentalapplication.Services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.ModelAttribute;

import com.rental.rentalapplication.DTO.UserPersonDto;
import com.rental.rentalapplication.Models.AccountType;
import com.rental.rentalapplication.Models.Cart;
import com.rental.rentalapplication.Models.FavouriteList;
import com.rental.rentalapplication.Models.Person;
import com.rental.rentalapplication.Models.User;
import com.rental.rentalapplication.Repository.AccountTypeRepository;
import com.rental.rentalapplication.Repository.CartRepository;
import com.rental.rentalapplication.Repository.CompanyRepository;
import com.rental.rentalapplication.Repository.FavouriteListRepository;
import com.rental.rentalapplication.Repository.PersonRepository;
import com.rental.rentalapplication.Repository.UserRepository;
import com.rental.rentalapplication.security.SecurityService;

import jakarta.transaction.Transactional;


@Service
public class AccountManager {
	
	@Autowired
	private UserRepository userRepo;
	@Autowired
	private PersonRepository personRepo; 

	@Autowired
	private CartRepository cartRepo;
	
	@Autowired
	private AccountTypeRepository accountTypeRepo;
	
	@Autowired
	private FavouriteListRepository favouriteListRepo;

	@Autowired
	private CompanyRepository companyRepo;
	
	@Autowired
	private SecurityService securityService;
	
	public void addAccount(@ModelAttribute UserPersonDto userPersonDto) {
		BCryptPasswordEncoder passwordEncoder= new BCryptPasswordEncoder();
		User user= new User(userPersonDto.getEmail(),passwordEncoder.encode(userPersonDto.getPassword()));
		AccountType accountType=accountTypeRepo.findByName("Użytkownik");
		user.setAccountType(accountType);
		Person person= new Person(userPersonDto.getFirstName(), userPersonDto.getSurname(), userPersonDto.getPhoneNumber());
		userRepo.save(user);
		person.setUser(user);
		personRepo.save(person);
		Cart cart=new Cart(user);
		cartRepo.save(cart);
		FavouriteList favouriteList= new FavouriteList(user);
		favouriteListRepo.save(favouriteList);
	}
	
	@Transactional
	public void deleteAccount(Authentication  authentication) {
		User user=securityService.getUserFromSession(authentication);
		if(user!=null) {
			personRepo.delete(user.getPerson());
			userRepo.delete(user);
			cartRepo.delete(user.getCart());
			favouriteListRepo.delete(user.getFavouriteList());
			if(user.getCompany()!=null) {
				companyRepo.delete(user.getCompany());
			}
		}
	}
}
