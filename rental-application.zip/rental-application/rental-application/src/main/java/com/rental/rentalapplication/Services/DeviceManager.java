package com.rental.rentalapplication.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.rental.rentalapplication.DTO.DeviceDto;
import com.rental.rentalapplication.Models.AudioDevice;
import com.rental.rentalapplication.Models.Camera;
import com.rental.rentalapplication.Models.Computer;
import com.rental.rentalapplication.Models.Connector;
import com.rental.rentalapplication.Models.Device;
import com.rental.rentalapplication.Models.DeviceRental;
import com.rental.rentalapplication.Models.ImageDisplay;
import com.rental.rentalapplication.Models.Lighting;

import com.rental.rentalapplication.Repository.AudioDeviceRepository;
import com.rental.rentalapplication.Repository.CameraRepository;
import com.rental.rentalapplication.Repository.ComputerRepository;
import com.rental.rentalapplication.Repository.DeviceRepository;
import com.rental.rentalapplication.Repository.ImageDisplayRepository;
import com.rental.rentalapplication.Repository.LightingRepository;


@Service
public class DeviceManager {
	
	@Autowired
	private AudioDeviceRepository audioDeviceRepo;
	
	@Autowired
	private CameraRepository cameraRepo;
	
	@Autowired
	private LightingRepository lightingRepo;
	
	@Autowired
	private ComputerRepository computerRepo;
	
	@Autowired
	private DeviceRepository deviceRepo;
	
	@Autowired
	private ImageDisplayRepository imageDisplayRepo;

	public void addDevice(@ModelAttribute DeviceDto deviceDto,RedirectAttributes redirectAttributes) {
		
		
			if(deviceDto.getCategory().getName().equals("telewizor")) {
				List<ImageDisplay> imageDisplays=imageDisplayRepo.findByScreenResolutionAndScreenSizeAndRefreshRate(deviceDto.getScreenResolution(),deviceDto.getScreenSize(),deviceDto.getRefreshRate());
				List<Device> devices=deviceRepo.findByCategoryNameAndNameAndPriceAndDepositAndDescription("telewizor", deviceDto.getName(), deviceDto.getPrice(), deviceDto.getDeposit(), deviceDto.getDescription());
				if(imageDisplays.isEmpty() && devices.isEmpty()){
					ImageDisplay newImageDisplay= new ImageDisplay(deviceDto.getScreenResolution(),deviceDto.getScreenSize(),deviceDto.getRefreshRate());
					imageDisplayRepo.save(newImageDisplay);
					Device newDevice = new Device(deviceDto.getCategory(), null, newImageDisplay, null, null, null, deviceDto.getName(), deviceDto.getPrice(), deviceDto.getDeposit(), deviceDto.getDescription());
					for ( Connector connector : deviceDto.getConnectors()) {
						newDevice.addConnector(connector);
					}
					deviceRepo.save(newDevice);
					newImageDisplay.addDevice(newDevice);
					redirectAttributes.addFlashAttribute("info", "Dodano urządzenie");
				}else if(!imageDisplays.isEmpty() && devices.isEmpty()){
					Device newDevice = new Device(deviceDto.getCategory(), null, imageDisplays.get(0),null, null, null, deviceDto.getName(), deviceDto.getPrice(), deviceDto.getDeposit(), deviceDto.getDescription());
					for ( Connector connector : deviceDto.getConnectors()) {
						newDevice.addConnector(connector);
					}
					deviceRepo.save(newDevice);
					imageDisplays.get(0).addDevice(newDevice);
					redirectAttributes.addFlashAttribute("info", "Dodano urządzenie");
				}else if(imageDisplays.isEmpty() && !devices.isEmpty()){
					ImageDisplay newImageDisplay= new ImageDisplay(deviceDto.getScreenResolution(),deviceDto.getScreenSize(),deviceDto.getRefreshRate());
					imageDisplayRepo.save(newImageDisplay);
					Device device2 = new Device(deviceDto.getCategory(), null,newImageDisplay, null, null, null, deviceDto.getName(), deviceDto.getPrice(), deviceDto.getDeposit(), deviceDto.getDescription());
					for ( Connector connector : deviceDto.getConnectors()) {
						device2.addConnector(connector);
					}
					deviceRepo.save(device2);
					newImageDisplay.addDevice(device2);
					redirectAttributes.addFlashAttribute("info", "Dodano urządzenie");
				}else if(!imageDisplays.isEmpty() && !devices.isEmpty()) {
					Device existingDevice=devices.get(devices.size()-1);
					Device device=new Device();
					device.setImageDisplay(imageDisplays.get(0));
					device.setName(existingDevice.getName());
					device.setPrice(existingDevice.getPrice());
					device.setDeposit(existingDevice.getDeposit());
					device.setDescription(existingDevice.getDescription());
					device.setCategory(existingDevice.getCategory());
					for ( Connector connector : deviceDto.getConnectors()) {
						device.addConnector(connector);
					}
					imageDisplays.get(0).addDevice(device);
					deviceRepo.save(device);
					redirectAttributes.addFlashAttribute("info", "Urządzenie istnieje");
				}
			}
			
			else if(deviceDto.getCategory().getName().equals("laptop")) {
				List<Computer> computers= computerRepo.findByDisplayAndProcessorAndDriveAndRamAndGraphicsCardAndOperatingSystem(deviceDto.getDisplay(), deviceDto.getProcessor(), deviceDto.getDrive(),deviceDto.getRam() , deviceDto.getGraphicsCard(), deviceDto.getOperatingSystem());
				List<Device> devices=deviceRepo.findByCategoryNameAndNameAndPriceAndDepositAndDescription("laptop", deviceDto.getName(), deviceDto.getPrice(), deviceDto.getDeposit(), deviceDto.getDescription());
				if(computers.isEmpty() && devices.isEmpty()){
					Computer newComputer= new Computer(deviceDto.getDisplay(), deviceDto.getProcessor(), deviceDto.getDrive(),deviceDto.getRam() , deviceDto.getGraphicsCard(), deviceDto.getOperatingSystem());
					computerRepo.save(newComputer);
					Device newDevice = new Device(deviceDto.getCategory(), newComputer, null, null, null, null, deviceDto.getName(), deviceDto.getPrice(), deviceDto.getDeposit(), deviceDto.getDescription());
					for ( Connector connector : deviceDto.getConnectors()) {
						newDevice.addConnector(connector);
					}
					deviceRepo.save(newDevice);
					redirectAttributes.addFlashAttribute("info", "Dodano urządzenie");
				}else if(!computers.isEmpty() && devices.isEmpty()){
					Device newDevice = new Device(deviceDto.getCategory(), computers.get(0), null,null, null, null, deviceDto.getName(), deviceDto.getPrice(), deviceDto.getDeposit(), deviceDto.getDescription());
					for ( Connector connector : deviceDto.getConnectors()) {
						newDevice.addConnector(connector);
					}
					deviceRepo.save(newDevice);
					redirectAttributes.addFlashAttribute("info", "Dodano urządzenie");
				}else if(computers.isEmpty() && !devices.isEmpty()){
					Computer newComputer= new Computer(deviceDto.getDisplay(), deviceDto.getProcessor(), deviceDto.getDrive(),deviceDto.getRam() , deviceDto.getGraphicsCard(), deviceDto.getOperatingSystem());
					computerRepo.save(newComputer);
					Device device2 = new Device(deviceDto.getCategory(), newComputer, null,null, null, null, deviceDto.getName(), deviceDto.getPrice(), deviceDto.getDeposit(), deviceDto.getDescription());
					for ( Connector connector : deviceDto.getConnectors()) {
						device2.addConnector(connector);
					}
					deviceRepo.save(device2);
					redirectAttributes.addFlashAttribute("info", "Dodano urządzenie");
				}else if(!computers.isEmpty() && !devices.isEmpty()) {
					Device existingDevice=devices.get(devices.size()-1);
					Device device=new Device();
					device.setComputer(computers.get(0));
					device.setName(existingDevice.getName());
					device.setPrice(existingDevice.getPrice());
					device.setDeposit(existingDevice.getDeposit());
					device.setDescription(existingDevice.getDescription());
					device.setCategory(existingDevice.getCategory());
					for ( Connector connector : deviceDto.getConnectors()) {
						device.addConnector(connector);
					}
					deviceRepo.save(device);
					redirectAttributes.addFlashAttribute("info", "Urządzenie istnieje");
				}
				
			}else if (deviceDto.getCategory().getName().equals("monitor")) {
				List<ImageDisplay> imageDisplays=imageDisplayRepo.findByScreenResolutionAndScreenSizeAndRefreshRate(deviceDto.getScreenResolution(),deviceDto.getScreenSize(),deviceDto.getRefreshRate());
				List<Device> devices=deviceRepo.findByCategoryNameAndNameAndPriceAndDepositAndDescription("monitor", deviceDto.getName(), deviceDto.getPrice(), deviceDto.getDeposit(), deviceDto.getDescription());
				if(imageDisplays.isEmpty() && devices.isEmpty()){
					ImageDisplay newImageDisplay= new ImageDisplay(deviceDto.getScreenResolution(),deviceDto.getScreenSize(),deviceDto.getRefreshRate());
					imageDisplayRepo.save(newImageDisplay);
					Device newDevice = new Device(deviceDto.getCategory(), null, newImageDisplay, null, null, null, deviceDto.getName(), deviceDto.getPrice(), deviceDto.getDeposit(), deviceDto.getDescription());
					for ( Connector connector : deviceDto.getConnectors()) {
						newDevice.addConnector(connector);
					}
					deviceRepo.save(newDevice);
					redirectAttributes.addFlashAttribute("info", "Dodano urządzenie");
				}else if(!imageDisplays.isEmpty() && devices.isEmpty()){
					Device newDevice = new Device(deviceDto.getCategory(), null, imageDisplays.get(0),null, null, null, deviceDto.getName(), deviceDto.getPrice(), deviceDto.getDeposit(), deviceDto.getDescription());
					for ( Connector connector : deviceDto.getConnectors()) {
						newDevice.addConnector(connector);
					}
					deviceRepo.save(newDevice);
					redirectAttributes.addFlashAttribute("info", "Dodano urządzenie");
				}else if(imageDisplays.isEmpty() && !devices.isEmpty()){
					ImageDisplay newImageDisplay= new ImageDisplay(deviceDto.getScreenResolution(),deviceDto.getScreenSize(),deviceDto.getRefreshRate());
					imageDisplayRepo.save(newImageDisplay);
					Device device2 = new Device(deviceDto.getCategory(), null,newImageDisplay, null, null, null, deviceDto.getName(), deviceDto.getPrice(), deviceDto.getDeposit(), deviceDto.getDescription());
					for ( Connector connector : deviceDto.getConnectors()) {
						device2.addConnector(connector);
					}
					deviceRepo.save(device2);
					redirectAttributes.addFlashAttribute("info", "Dodano urządzenie");
				}else if(!imageDisplays.isEmpty() && !devices.isEmpty()) {
					Device existingDevice=devices.get(devices.size()-1);
					Device device=new Device();
					device.setImageDisplay(imageDisplays.get(0));
					device.setName(existingDevice.getName());
					device.setPrice(existingDevice.getPrice());
					device.setDeposit(existingDevice.getDeposit());
					device.setDescription(existingDevice.getDescription());
					device.setCategory(existingDevice.getCategory());
					for ( Connector connector : deviceDto.getConnectors()) {
						device.addConnector(connector);
					}
					deviceRepo.save(device);
					redirectAttributes.addFlashAttribute("info", "Urządzenie istnieje");
				}
			}else if (deviceDto.getCategory().getName().equals("nagłośnienie")) {
				
				List<AudioDevice> audioDevices=audioDeviceRepo.findBySpeakersPowerAndNumberOfspeakers(deviceDto.getSpeakersPower(), deviceDto.getNumberOfspeakers());
				List<Device> devices=deviceRepo.findByCategoryNameAndNameAndPriceAndDepositAndDescription("nagłośnienie", deviceDto.getName(), deviceDto.getPrice(), deviceDto.getDeposit(), deviceDto.getDescription());
				if(audioDevices.isEmpty() && devices.isEmpty()){
					AudioDevice newAudioDevice= new AudioDevice(deviceDto.getSpeakersPower(), deviceDto.getNumberOfspeakers());
					audioDeviceRepo.save(newAudioDevice);
					Device newDevice = new Device(deviceDto.getCategory(), null, null, null, newAudioDevice, null, deviceDto.getName(), deviceDto.getPrice(), deviceDto.getDeposit(), deviceDto.getDescription());
					for ( Connector connector : deviceDto.getConnectors()) {
						newDevice.addConnector(connector);
					}
					deviceRepo.save(newDevice);
					redirectAttributes.addFlashAttribute("info", "Dodano urządzenie");
				}else if(!audioDevices.isEmpty() && devices.isEmpty()){
					Device newDevice = new Device(deviceDto.getCategory(), null, null,null, audioDevices.get(0), null, deviceDto.getName(), deviceDto.getPrice(), deviceDto.getDeposit(), deviceDto.getDescription());
					for ( Connector connector : deviceDto.getConnectors()) {
						newDevice.addConnector(connector);
					}
					deviceRepo.save(newDevice);
					redirectAttributes.addFlashAttribute("info", "Dodano urządzenie");
				}else if(audioDevices.isEmpty() && !devices.isEmpty()){
					AudioDevice newAudioDevice= new AudioDevice(deviceDto.getSpeakersPower(), deviceDto.getNumberOfspeakers());
					audioDeviceRepo.save(newAudioDevice);
					Device device2 = new Device(deviceDto.getCategory(), null,null, null, newAudioDevice, null, deviceDto.getName(), deviceDto.getPrice(), deviceDto.getDeposit(), deviceDto.getDescription());
					for ( Connector connector : deviceDto.getConnectors()) {
						device2.addConnector(connector);
					}
					deviceRepo.save(device2);
					redirectAttributes.addFlashAttribute("info", "Dodano urządzenie");
				}else if(!audioDevices.isEmpty() && !devices.isEmpty()) {
					Device existingDevice=devices.get(devices.size()-1);
					Device device=new Device();
					device.setAudioDevice(audioDevices.get(0));
					device.setName(existingDevice.getName());
					device.setPrice(existingDevice.getPrice());
					device.setDeposit(existingDevice.getDeposit());
					device.setDescription(existingDevice.getDescription());
					device.setCategory(existingDevice.getCategory());
					for ( Connector connector : deviceDto.getConnectors()) {
						device.addConnector(connector);
					}
					deviceRepo.save(device);
					redirectAttributes.addFlashAttribute("info", "Urządzenie istnieje");
				}
				
			}else if (deviceDto.getCategory().getName().equals("projektor multimedialny")){
				List<ImageDisplay> imageDisplays=imageDisplayRepo.findByMatrixTypeAndLampPowerAndScreenResolution(deviceDto.getMatrixType(),deviceDto.getLampPower(),deviceDto.getScreenResolution());
				List<Device> devices=deviceRepo.findByCategoryNameAndNameAndPriceAndDepositAndDescription("projektor multimedialny", deviceDto.getName(), deviceDto.getPrice(), deviceDto.getDeposit(), deviceDto.getDescription());
				if(imageDisplays.isEmpty() && devices.isEmpty()){
					ImageDisplay newImageDisplay= new ImageDisplay(deviceDto.getMatrixType(),deviceDto.getLampPower(),deviceDto.getScreenResolution());
					imageDisplayRepo.save(newImageDisplay);
					Device newDevice = new Device(deviceDto.getCategory(), null, newImageDisplay, null, null, null, deviceDto.getName(), deviceDto.getPrice(), deviceDto.getDeposit(), deviceDto.getDescription());
					for ( Connector connector : deviceDto.getConnectors()) {
						newDevice.addConnector(connector);
					}
					deviceRepo.save(newDevice);
					redirectAttributes.addFlashAttribute("info", "Dodano urządzenie");
				}else if(!imageDisplays.isEmpty() && devices.isEmpty()){
					Device newDevice = new Device(deviceDto.getCategory(), null, imageDisplays.get(0),null, null, null, deviceDto.getName(), deviceDto.getPrice(), deviceDto.getDeposit(), deviceDto.getDescription());
					for ( Connector connector : deviceDto.getConnectors()) {
						newDevice.addConnector(connector);
					}
					deviceRepo.save(newDevice);
					redirectAttributes.addFlashAttribute("info", "Dodano urządzenie");
				}else if(imageDisplays.isEmpty() && !devices.isEmpty()){
					ImageDisplay newImageDisplay= new ImageDisplay(deviceDto.getMatrixType(),deviceDto.getLampPower(),deviceDto.getScreenResolution());
					imageDisplayRepo.save(newImageDisplay);
					Device device2 = new Device(deviceDto.getCategory(), null,newImageDisplay, null, null, null, deviceDto.getName(), deviceDto.getPrice(), deviceDto.getDeposit(), deviceDto.getDescription());
					for ( Connector connector : deviceDto.getConnectors()) {
						device2.addConnector(connector);
					}
					deviceRepo.save(device2);
					redirectAttributes.addFlashAttribute("info", "Dodano urządzenie");
				}else if(!imageDisplays.isEmpty() && !devices.isEmpty()) {
					Device existingDevice=devices.get(devices.size()-1);
					Device device=new Device();
					device.setImageDisplay(imageDisplays.get(0));
					device.setName(existingDevice.getName());
					device.setPrice(existingDevice.getPrice());
					device.setDeposit(existingDevice.getDeposit());
					device.setDescription(existingDevice.getDescription());
					device.setCategory(existingDevice.getCategory());
					for ( Connector connector : deviceDto.getConnectors()) {
						device.addConnector(connector);
					}
					deviceRepo.save(device);
					redirectAttributes.addFlashAttribute("info", "Urządzenie istnieje");
				}
				
			}else if (deviceDto.getCategory().getName().equals("ekran")) {
				List<ImageDisplay> imageDisplays=imageDisplayRepo.findByScreenFormatAndScreenSizeAndActiveSurface(deviceDto.getScreenFormat(),deviceDto.getScreenSize(),deviceDto.getActiveSurface());
				List<Device> devices=deviceRepo.findByCategoryNameAndNameAndPriceAndDepositAndDescription("ekran", deviceDto.getName(), deviceDto.getPrice(), deviceDto.getDeposit(), deviceDto.getDescription());
				if(imageDisplays.isEmpty() && devices.isEmpty()){
					ImageDisplay newImageDisplay= new ImageDisplay(deviceDto.getScreenFormat(),deviceDto.getScreenSize(),deviceDto.getActiveSurface());
					imageDisplayRepo.save(newImageDisplay);
					Device newDevice = new Device(deviceDto.getCategory(), null, newImageDisplay, null, null, null, deviceDto.getName(), deviceDto.getPrice(), deviceDto.getDeposit(), deviceDto.getDescription());
					for ( Connector connector : deviceDto.getConnectors()) {
						newDevice.addConnector(connector);
					}
					deviceRepo.save(newDevice);
					redirectAttributes.addFlashAttribute("info", "Dodano urządzenie");
				}else if(!imageDisplays.isEmpty() && devices.isEmpty()){
					Device newDevice = new Device(deviceDto.getCategory(), null, imageDisplays.get(0),null, null, null, deviceDto.getName(), deviceDto.getPrice(), deviceDto.getDeposit(), deviceDto.getDescription());
					for ( Connector connector : deviceDto.getConnectors()) {
						newDevice.addConnector(connector);
					}
					deviceRepo.save(newDevice);
					redirectAttributes.addFlashAttribute("info", "Dodano urządzenie");
				}else if(imageDisplays.isEmpty() && !devices.isEmpty()){
					ImageDisplay newImageDisplay= new ImageDisplay(deviceDto.getScreenFormat(),deviceDto.getScreenSize(),deviceDto.getActiveSurface());
					imageDisplayRepo.save(newImageDisplay);
					Device device2 = new Device(deviceDto.getCategory(), null,newImageDisplay, null, null, null, deviceDto.getName(), deviceDto.getPrice(), deviceDto.getDeposit(), deviceDto.getDescription());
					for ( Connector connector : deviceDto.getConnectors()) {
						device2.addConnector(connector);
					}
					deviceRepo.save(device2);
					redirectAttributes.addFlashAttribute("info", "Dodano urządzenie");
				}else if(!imageDisplays.isEmpty() && !devices.isEmpty()) {
					Device existingDevice=devices.get(devices.size()-1);
					Device device=new Device();
					device.setImageDisplay(imageDisplays.get(0));
					device.setName(existingDevice.getName());
					device.setPrice(existingDevice.getPrice());
					device.setDeposit(existingDevice.getDeposit());
					device.setDescription(existingDevice.getDescription());
					device.setCategory(existingDevice.getCategory());
					for ( Connector connector : deviceDto.getConnectors()) {
						device.addConnector(connector);
					}
					deviceRepo.save(device);
					redirectAttributes.addFlashAttribute("info", "Urządzenie istnieje");
				}
				
			}else if (deviceDto.getCategory().getName().equals("oświetlenie")) {
				List<Lighting> lightings= lightingRepo.findByLightingColorAndPowerConsumptionAndLampPowerAndDeviceSize(deviceDto.getLightingColor(),deviceDto.getPowerConsumption(), deviceDto.getLampPower(), deviceDto.getDeviceSize());
				List<Device> devices=deviceRepo.findByCategoryNameAndNameAndPriceAndDepositAndDescription("oświetlenie", deviceDto.getName(), deviceDto.getPrice(), deviceDto.getDeposit(), deviceDto.getDescription());
				if(lightings.isEmpty() && devices.isEmpty()){
					Lighting newLighting= new Lighting(deviceDto.getLightingColor(),deviceDto.getPowerConsumption(), deviceDto.getLampPower(), deviceDto.getDeviceSize());
					lightingRepo.save(newLighting);
					Device newDevice = new Device(deviceDto.getCategory(), null, null, null, null, newLighting, deviceDto.getName(), deviceDto.getPrice(), deviceDto.getDeposit(), deviceDto.getDescription());
					for ( Connector connector : deviceDto.getConnectors()) {
						newDevice.addConnector(connector);
					}
					deviceRepo.save(newDevice);
					redirectAttributes.addFlashAttribute("info", "Dodano urządzenie");
				}else if(!lightings.isEmpty() && devices.isEmpty()){
					
					Device newDevice = new Device(deviceDto.getCategory(), null, null,null, null, lightings.get(0), deviceDto.getName(), deviceDto.getPrice(), deviceDto.getDeposit(), deviceDto.getDescription());
					for ( Connector connector : deviceDto.getConnectors()) {
						newDevice.addConnector(connector);
					}
					deviceRepo.save(newDevice);
					redirectAttributes.addFlashAttribute("info", "Dodano urządzenie");
				}else if(lightings.isEmpty() && !devices.isEmpty()){
					Lighting newLighting= new Lighting(deviceDto.getLightingColor(),deviceDto.getPowerConsumption(), deviceDto.getLampPower(), deviceDto.getDeviceSize());
					lightingRepo.save(newLighting);
					Device device2 = new Device(deviceDto.getCategory(), null, null,null, null, newLighting, deviceDto.getName(), deviceDto.getPrice(), deviceDto.getDeposit(), deviceDto.getDescription());
					for ( Connector connector : deviceDto.getConnectors()) {
						device2.addConnector(connector);
					}
					deviceRepo.save(device2);
					redirectAttributes.addFlashAttribute("info", "Dodano urządzenie");
				}else if(!lightings.isEmpty() && !devices.isEmpty()) {
					Device existingDevice=devices.get(devices.size()-1);
					Device device=new Device();
					device.setLighting(lightings.get(0));
					device.setName(existingDevice.getName());
					device.setPrice(existingDevice.getPrice());
					device.setDeposit(existingDevice.getDeposit());
					device.setDescription(existingDevice.getDescription());
					device.setCategory(existingDevice.getCategory());
					for ( Connector connector : deviceDto.getConnectors()) {
						device.addConnector(connector);
					}
					deviceRepo.save(device);
					redirectAttributes.addFlashAttribute("info", "Urządzenie istnieje");
				}
			}else if(deviceDto.getCategory().getName().equals("słuchawki")){
				List<AudioDevice> audioDevices=audioDeviceRepo.findByHeadphoneTypeAndMicrophoneAndWorkingTimeAndWirelessTransmission(deviceDto.getHeadphoneType(), deviceDto.isMicrophone(),deviceDto.getWorkingTime(),deviceDto.isWirelessTransmission());
				List<Device> devices=deviceRepo.findByCategoryNameAndNameAndPriceAndDepositAndDescription("słuchawki", deviceDto.getName(), deviceDto.getPrice(), deviceDto.getDeposit(), deviceDto.getDescription());
				if(audioDevices.isEmpty() && devices.isEmpty()){
					AudioDevice newAudioDevice= new AudioDevice(deviceDto.getHeadphoneType(), deviceDto.isMicrophone(),deviceDto.getWorkingTime(),deviceDto.isWirelessTransmission());
					audioDeviceRepo.save(newAudioDevice);
					Device newDevice = new Device(deviceDto.getCategory(), null, null, null, newAudioDevice, null, deviceDto.getName(), deviceDto.getPrice(), deviceDto.getDeposit(), deviceDto.getDescription());
					for ( Connector connector : deviceDto.getConnectors()) {
						newDevice.addConnector(connector);
					}
					deviceRepo.save(newDevice);
					redirectAttributes.addFlashAttribute("info", "Dodano urządzenie");
				}else if(!audioDevices.isEmpty() && devices.isEmpty()){
					Device newDevice = new Device(deviceDto.getCategory(), null, null,null, audioDevices.get(0), null, deviceDto.getName(), deviceDto.getPrice(), deviceDto.getDeposit(), deviceDto.getDescription());
					for ( Connector connector : deviceDto.getConnectors()) {
						newDevice.addConnector(connector);
					}
					deviceRepo.save(newDevice);
					redirectAttributes.addFlashAttribute("info", "Dodano urządzenie");
				}else if(audioDevices.isEmpty() && !devices.isEmpty()){
					AudioDevice newAudioDevice= new AudioDevice(deviceDto.getHeadphoneType(), deviceDto.isMicrophone(),deviceDto.getWorkingTime(),deviceDto.isWirelessTransmission());
					audioDeviceRepo.save(newAudioDevice);
					Device device2 = new Device(deviceDto.getCategory(), null,null, null, newAudioDevice, null, deviceDto.getName(), deviceDto.getPrice(), deviceDto.getDeposit(), deviceDto.getDescription());
					for ( Connector connector : deviceDto.getConnectors()) {
						device2.addConnector(connector);
					}
					deviceRepo.save(device2);
					redirectAttributes.addFlashAttribute("info", "Dodano urządzenie");
				}else if(!audioDevices.isEmpty() && !devices.isEmpty()) {
					Device existingDevice=devices.get(devices.size()-1);
					Device device=new Device();
					device.setAudioDevice(audioDevices.get(0));
					device.setName(existingDevice.getName());
					device.setPrice(existingDevice.getPrice());
					device.setDeposit(existingDevice.getDeposit());
					device.setDescription(existingDevice.getDescription());
					device.setCategory(existingDevice.getCategory());
					for ( Connector connector : deviceDto.getConnectors()) {
						device.addConnector(connector);
					}
					deviceRepo.save(device);
					redirectAttributes.addFlashAttribute("info", "Urządzenie istnieje");
				}
			}else if (deviceDto.getCategory().getName().equals("tablet")) {
				List<Computer> computers= computerRepo.findByDisplayAndProcessorAndDriveAndRamAndOperatingSystem(deviceDto.getDisplay(), deviceDto.getProcessor(), deviceDto.getDrive(),deviceDto.getRam(), deviceDto.getOperatingSystem());
				List<Device> devices=deviceRepo.findByCategoryNameAndNameAndPriceAndDepositAndDescription("tablet", deviceDto.getName(), deviceDto.getPrice(), deviceDto.getDeposit(), deviceDto.getDescription());
				if(computers.isEmpty() && devices.isEmpty()){
					Computer newComputer= new Computer(deviceDto.getDisplay(), deviceDto.getProcessor(), deviceDto.getDrive(),deviceDto.getRam(), deviceDto.getOperatingSystem());
					computerRepo.save(newComputer);
					Device newDevice = new Device(deviceDto.getCategory(), newComputer, null, null, null, null, deviceDto.getName(), deviceDto.getPrice(), deviceDto.getDeposit(), deviceDto.getDescription());
					for ( Connector connector : deviceDto.getConnectors()) {
						newDevice.addConnector(connector);
					}
					deviceRepo.save(newDevice);
					redirectAttributes.addFlashAttribute("info", "Dodano urządzenie");
				}else if(!computers.isEmpty() && devices.isEmpty()){
					Device newDevice = new Device(deviceDto.getCategory(), computers.get(0), null,null, null, null, deviceDto.getName(), deviceDto.getPrice(), deviceDto.getDeposit(), deviceDto.getDescription());
					for ( Connector connector : deviceDto.getConnectors()) {
						newDevice.addConnector(connector);
					}
					deviceRepo.save(newDevice);
					redirectAttributes.addFlashAttribute("info", "Dodano urządzenie");
				}else if(computers.isEmpty() && !devices.isEmpty()){
					Computer newComputer= new Computer(deviceDto.getDisplay(), deviceDto.getProcessor(), deviceDto.getDrive(),deviceDto.getRam(), deviceDto.getOperatingSystem());
					computerRepo.save(newComputer);
					Device device2 = new Device(deviceDto.getCategory(), newComputer, null,null, null, null, deviceDto.getName(), deviceDto.getPrice(), deviceDto.getDeposit(), deviceDto.getDescription());
					for ( Connector connector : deviceDto.getConnectors()) {
						device2.addConnector(connector);
					}
					deviceRepo.save(device2);
					redirectAttributes.addFlashAttribute("info", "Dodano urządzenie");
				}else if(!computers.isEmpty() && !devices.isEmpty()) {
					Device existingDevice=devices.get(devices.size()-1);
					Device device=new Device();
					device.setComputer(computers.get(0));
					device.setName(existingDevice.getName());
					device.setPrice(existingDevice.getPrice());
					device.setDeposit(existingDevice.getDeposit());
					device.setDescription(existingDevice.getDescription());
					device.setCategory(existingDevice.getCategory());
					for ( Connector connector : deviceDto.getConnectors()) {
						device.addConnector(connector);
					}
					deviceRepo.save(device);
					redirectAttributes.addFlashAttribute("info", "Urządzenie istnieje");
				}
			}else if (deviceDto.getCategory().getName().equals("kamera")) {
				List<Camera> cameras=cameraRepo.findByResolutionAndImageStabilizationAndOpticalZoom(deviceDto.getResolution(), deviceDto.isImageStabilization(), deviceDto.isOpticalZoom());
				List<Device> devices=deviceRepo.findByCategoryNameAndNameAndPriceAndDepositAndDescription("kamera", deviceDto.getName(), deviceDto.getPrice(), deviceDto.getDeposit(), deviceDto.getDescription());
				if(cameras.isEmpty() && devices.isEmpty()){
					Camera newCamera= new Camera(deviceDto.getResolution(),deviceDto.isImageStabilization(), deviceDto.isOpticalZoom());
					cameraRepo.save(newCamera);
					Device newDevice = new Device(deviceDto.getCategory(), null, null, newCamera, null, null, deviceDto.getName(), deviceDto.getPrice(), deviceDto.getDeposit(), deviceDto.getDescription());
					for ( Connector connector : deviceDto.getConnectors()) {
						newDevice.addConnector(connector);
					}
					deviceRepo.save(newDevice);
					redirectAttributes.addFlashAttribute("info", "Dodano urządzenie");
				}else if(!cameras.isEmpty() && devices.isEmpty()){
					
					Device newDevice = new Device(deviceDto.getCategory(), null, null,cameras.get(0), null, null, deviceDto.getName(), deviceDto.getPrice(), deviceDto.getDeposit(), deviceDto.getDescription());
					for ( Connector connector : deviceDto.getConnectors()) {
						newDevice.addConnector(connector);
					}
					deviceRepo.save(newDevice);
					redirectAttributes.addFlashAttribute("info", "Dodano urządzenie");
				}else if(cameras.isEmpty() && !devices.isEmpty()){
					Camera newCamera= new Camera(deviceDto.getResolution(),deviceDto.isImageStabilization(), deviceDto.isOpticalZoom());
					cameraRepo.save(newCamera);
					Device device2 = new Device(deviceDto.getCategory(), null, null, newCamera, null, null, deviceDto.getName(), deviceDto.getPrice(), deviceDto.getDeposit(), deviceDto.getDescription());
					for ( Connector connector : deviceDto.getConnectors()) {
						device2.addConnector(connector);
					}
					deviceRepo.save(device2);
					redirectAttributes.addFlashAttribute("info", "Dodano urządzenie");
				}else if(!cameras.isEmpty() && !devices.isEmpty()) {
					Device existingDevice=devices.get(devices.size()-1);
					Device device=new Device();
					device.setCamera(cameras.get(0));
					device.setName(existingDevice.getName());
					device.setPrice(existingDevice.getPrice());
					device.setDeposit(existingDevice.getDeposit());
					device.setDescription(existingDevice.getDescription());
					device.setCategory(existingDevice.getCategory());
					for ( Connector connector : deviceDto.getConnectors()) {
						device.addConnector(connector);
					}
					deviceRepo.save(device);
					redirectAttributes.addFlashAttribute("info", "Urządzenie istnieje");
				}
			}else if (deviceDto.getCategory().getName().equals("mikrofon")) {
				List<AudioDevice> audioDevices=audioDeviceRepo.findByFrequencyResponseAndMicrophoneTypeAndWirelessTransmission(deviceDto.getFrequencyResponse(),deviceDto.getMicrophoneType(),deviceDto.isWirelessTransmission());
				List<Device> devices=deviceRepo.findByCategoryNameAndNameAndPriceAndDepositAndDescription("mikrofon", deviceDto.getName(), deviceDto.getPrice(), deviceDto.getDeposit(), deviceDto.getDescription());
				if(audioDevices.isEmpty() && devices.isEmpty()){
					AudioDevice newAudioDevice= new AudioDevice(deviceDto.getFrequencyResponse(),deviceDto.getMicrophoneType(),deviceDto.isWirelessTransmission());
					audioDeviceRepo.save(newAudioDevice);
					Device newDevice = new Device(deviceDto.getCategory(), null, null, null, newAudioDevice, null, deviceDto.getName(), deviceDto.getPrice(), deviceDto.getDeposit(), deviceDto.getDescription());
					for ( Connector connector : deviceDto.getConnectors()) {
						newDevice.addConnector(connector);
					}
					deviceRepo.save(newDevice);
					redirectAttributes.addFlashAttribute("info", "Dodano urządzenie");
				}else if(!audioDevices.isEmpty() && devices.isEmpty()){
					Device newDevice = new Device(deviceDto.getCategory(), null, null,null, audioDevices.get(0), null, deviceDto.getName(), deviceDto.getPrice(), deviceDto.getDeposit(), deviceDto.getDescription());
					for ( Connector connector : deviceDto.getConnectors()) {
						newDevice.addConnector(connector);
					}
					deviceRepo.save(newDevice);
					redirectAttributes.addFlashAttribute("info", "Dodano urządzenie");
				}else if(audioDevices.isEmpty() && !devices.isEmpty()){
					AudioDevice newAudioDevice= new AudioDevice(deviceDto.getFrequencyResponse(),deviceDto.getMicrophoneType(),deviceDto.isWirelessTransmission());
					audioDeviceRepo.save(newAudioDevice);
					Device device2 = new Device(deviceDto.getCategory(), null,null, null, newAudioDevice, null, deviceDto.getName(), deviceDto.getPrice(), deviceDto.getDeposit(), deviceDto.getDescription());
					for ( Connector connector : deviceDto.getConnectors()) {
						device2.addConnector(connector);
					}
					deviceRepo.save(device2);
					redirectAttributes.addFlashAttribute("info", "Dodano urządzenie");
				}else if(!audioDevices.isEmpty() && !devices.isEmpty()) {
					Device existingDevice=devices.get(devices.size()-1);
					Device device=new Device();
					device.setAudioDevice(audioDevices.get(0));
					device.setName(existingDevice.getName());
					device.setPrice(existingDevice.getPrice());
					device.setDeposit(existingDevice.getDeposit());
					device.setDescription(existingDevice.getDescription());
					device.setCategory(existingDevice.getCategory());
					for ( Connector connector : deviceDto.getConnectors()) {
						device.addConnector(connector);
					}
					deviceRepo.save(device);
					redirectAttributes.addFlashAttribute("info", "Urządzenie istnieje");
				}
			}
		}
	
	public List<Device> showDevices(){
		return deviceRepo.findAll();
	}
		
	public void deleteDevice(@PathVariable Integer id) {
		try {
			Device device=deviceRepo.findById(id).get();
			deviceRepo.delete(device);	
		}catch(Exception ex) {
			System.out.println("Exception: " + ex.getMessage());
		}}
	
	public Device getDevice(Integer id) {
		return deviceRepo.findById(id).get();
	}
	
	public void modify(DeviceDto deviceDto,Integer id)	{
		Device device=deviceRepo.findById(id).get();
		device.setName(deviceDto.getName());
		device.setPrice(deviceDto.getPrice());
		device.setDeposit(deviceDto.getDeposit());
		device.setDescription(deviceDto.getDescription());
		deviceRepo.save(device);
		
		switch(device.getCategory().getName()){
		case "telewizor":
			List<ImageDisplay> tvs=imageDisplayRepo.findByScreenResolutionAndScreenSizeAndRefreshRate(deviceDto.getScreenResolution(),deviceDto.getScreenSize(), deviceDto.getRefreshRate());
			if(tvs.isEmpty()) {
				ImageDisplay newImageDisplay= new ImageDisplay(deviceDto.getScreenResolution(), deviceDto.getScreenSize(), deviceDto.getRefreshRate());
				imageDisplayRepo.save(newImageDisplay);
				device.setImageDisplay(newImageDisplay);
				deviceRepo.save(device);
			}else if (!tvs.isEmpty()){
				device.setImageDisplay(tvs.get(0));
				deviceRepo.save(device);
			}
			break;
		case "monitor":
			List<ImageDisplay> displays=imageDisplayRepo.findByScreenResolutionAndScreenSizeAndRefreshRate(deviceDto.getScreenResolution(),deviceDto.getScreenSize(), deviceDto.getRefreshRate());
			if(displays.isEmpty()) {
				ImageDisplay newImageDisplay= new ImageDisplay(deviceDto.getScreenResolution(), deviceDto.getScreenSize(), deviceDto.getRefreshRate());
				imageDisplayRepo.save(newImageDisplay);
				device.setImageDisplay(newImageDisplay);
				deviceRepo.save(device);
			}else if (!displays.isEmpty()){
				device.setImageDisplay(displays.get(0));
				deviceRepo.save(device);
			}
			break;
		case "ekran":
			List<ImageDisplay> screens=imageDisplayRepo.findByScreenFormatAndScreenSizeAndActiveSurface(deviceDto.getScreenFormat(),deviceDto.getScreenSize(),deviceDto.getActiveSurface());
			if(screens.isEmpty()) {
				ImageDisplay newImageDisplay= new ImageDisplay(deviceDto.getScreenFormat(), deviceDto.getScreenSize(), deviceDto.getActiveSurface());
				imageDisplayRepo.save(newImageDisplay);
				device.setImageDisplay(newImageDisplay);
				deviceRepo.save(device);
			}else if (!screens.isEmpty()){
				device.setImageDisplay(screens.get(0));
				deviceRepo.save(device);
			}
			break;
		case "projektor multimedialny":
			List<ImageDisplay> projectors=imageDisplayRepo.findByMatrixTypeAndLampPowerAndScreenResolution(deviceDto.getMatrixType(),deviceDto.getLampPower(),deviceDto.getScreenResolution());
			if(projectors.isEmpty()) {
				ImageDisplay newImageDisplay= new ImageDisplay(deviceDto.getMatrixType(), deviceDto.getLampPower(), deviceDto.getScreenResolution());
				imageDisplayRepo.save(newImageDisplay);
				device.setImageDisplay(newImageDisplay);
				deviceRepo.save(device);
			}else if (!projectors.isEmpty()){
				device.setImageDisplay(projectors.get(0));
				deviceRepo.save(device);
			}
			break;
		case "laptop":
			List<Computer> laptops=computerRepo.findByDisplayAndProcessorAndDriveAndRamAndGraphicsCardAndOperatingSystem(deviceDto.getDisplay(), deviceDto.getProcessor(), deviceDto.getDrive(), deviceDto.getRam(), deviceDto.getGraphicsCard(), deviceDto.getOperatingSystem());
			if(laptops.isEmpty()) {
				Computer newComputer= new Computer(deviceDto.getDisplay(), deviceDto.getProcessor(), deviceDto.getDrive(), deviceDto.getRam(), deviceDto.getGraphicsCard(), deviceDto.getOperatingSystem());
				computerRepo.save(newComputer);
				device.setComputer(newComputer);
				deviceRepo.save(device);
			}else if (!laptops.isEmpty()){
				device.setComputer(laptops.get(0));
				deviceRepo.save(device);
			}
			break;
			
		case "tablet":
			List<Computer> tablets=computerRepo.findByDisplayAndProcessorAndDriveAndRamAndOperatingSystem(deviceDto.getDisplay(), deviceDto.getProcessor(), deviceDto.getDrive(), deviceDto.getRam(), deviceDto.getOperatingSystem());
			if(tablets.isEmpty()) {
				Computer newComputer= new Computer(deviceDto.getDisplay(), deviceDto.getProcessor(), deviceDto.getDrive(), deviceDto.getRam(), deviceDto.getOperatingSystem());
				computerRepo.save(newComputer);
				device.setComputer(newComputer);
				deviceRepo.save(device);
			}else if (!tablets.isEmpty()){
				device.setComputer(tablets.get(0));
				deviceRepo.save(device);
			}
			break;
		case "oświetlenie":
			List<Lighting> lightings=lightingRepo.findByLightingColorAndPowerConsumptionAndLampPowerAndDeviceSize(deviceDto.getLightingColor(),deviceDto.getPowerConsumption(),deviceDto.getLampPower(),deviceDto.getDeviceSize());
			if(lightings.isEmpty()) {
				Lighting newLighting= new Lighting(deviceDto.getLightingColor(),deviceDto.getPowerConsumption(),deviceDto.getLampPower(),deviceDto.getDeviceSize());
				lightingRepo.save(newLighting);
				device.setLighting(newLighting);
				deviceRepo.save(device);
			}else if (!lightings.isEmpty()){
				device.setLighting(lightings.get(0));
				deviceRepo.save(device);
			}
			break;
			
		case "kamera":
			List<Camera> cameras=cameraRepo.findByResolutionAndImageStabilizationAndOpticalZoom(deviceDto.getResolution(), deviceDto.isImageStabilization(), deviceDto.isOpticalZoom());
			if(cameras.isEmpty()) {
				Camera newCamera= new Camera(deviceDto.getResolution(), deviceDto.isImageStabilization(), deviceDto.isOpticalZoom());
				cameraRepo.save(newCamera);
				device.setCamera(newCamera);
				deviceRepo.save(device);
			}else if (!cameras.isEmpty()){
				device.setCamera(cameras.get(0));
				deviceRepo.save(device);
			}
			break;
			
		case "nagłośnienie":
			List<AudioDevice> audioDevices=audioDeviceRepo.findBySpeakersPowerAndNumberOfspeakers(deviceDto.getSpeakersPower(),deviceDto.getNumberOfspeakers());
			if(audioDevices.isEmpty()) {
				AudioDevice newAudioDevice= new AudioDevice(deviceDto.getSpeakersPower(),deviceDto.getNumberOfspeakers());
				audioDeviceRepo.save(newAudioDevice);
				device.setAudioDevice(newAudioDevice);
				deviceRepo.save(device);
			}else if (!audioDevices.isEmpty()){
				device.setAudioDevice(audioDevices.get(0));
				deviceRepo.save(device);
			}
			break;
		case "mikrofon":
			List<AudioDevice> microphons=audioDeviceRepo.findByFrequencyResponseAndMicrophoneTypeAndWirelessTransmission(deviceDto.getFrequencyResponse(),deviceDto.getMicrophoneType(),deviceDto.isWirelessTransmission());
			if(microphons.isEmpty()) {
				AudioDevice newAudioDevice= new AudioDevice(deviceDto.getFrequencyResponse(),deviceDto.getMicrophoneType(),deviceDto.isWirelessTransmission());
				audioDeviceRepo.save(newAudioDevice);
				device.setAudioDevice(newAudioDevice);
				deviceRepo.save(device);
			}else if (!microphons.isEmpty()){
				device.setAudioDevice(microphons.get(0));
				deviceRepo.save(device);
			}
			break;
		case "słuchawki":
			List<AudioDevice> headphones=audioDeviceRepo.findByHeadphoneTypeAndMicrophoneAndWorkingTimeAndWirelessTransmission(deviceDto.getHeadphoneType(),deviceDto.isMicrophone(),deviceDto.getWorkingTime(),deviceDto.isWirelessTransmission());
			if(headphones.isEmpty()) {
				AudioDevice newAudioDevice= new AudioDevice(deviceDto.getHeadphoneType(),deviceDto.isMicrophone(),deviceDto.getWorkingTime(),deviceDto.isWirelessTransmission());
				audioDeviceRepo.save(newAudioDevice);
				device.setAudioDevice(newAudioDevice);
				deviceRepo.save(device);
			}else if (!headphones.isEmpty()){
				device.setAudioDevice(headphones.get(0));
				deviceRepo.save(device);
			}
			break;
		}
	}
	
	
	public Boolean isAvaliable(Integer id) {
		Device device =deviceRepo.findById(id).get();
			Boolean isAvaliable=true;
			for(DeviceRental deviceRental : device.getDeviceRental()) {
				if(deviceRental.getRental().getRentalStatus().getName().equals("Wypożyczone") || deviceRental.getRental().getRentalStatus().getName().equals("Nowe") || deviceRental.getRental().getRentalStatus().getName().equals("W trakcie przygotowania") || deviceRental.getRental().getRentalStatus().getName().equals("Gotowe do odbioru")) {
					isAvaliable=false;
					break;}
			}
		return isAvaliable;		
		}
	
}
	

