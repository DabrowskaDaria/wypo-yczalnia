package com.rental.rentalapplication.Services;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import com.rental.rentalapplication.RentalCost;
import com.rental.rentalapplication.DTO.CartDataDto;
import com.rental.rentalapplication.DTO.CartMetodsDto;
import com.rental.rentalapplication.DTO.CompanyDto;
import com.rental.rentalapplication.DTO.PersonDto;
import com.rental.rentalapplication.Models.Cart;
import com.rental.rentalapplication.Models.Company;
import com.rental.rentalapplication.Models.Device;
import com.rental.rentalapplication.Models.DeviceCart;
import com.rental.rentalapplication.Models.DeviceRental;
import com.rental.rentalapplication.Models.Invoice;
import com.rental.rentalapplication.Models.InvoiceType;
import com.rental.rentalapplication.Models.Person;
import com.rental.rentalapplication.Models.Rental;
import com.rental.rentalapplication.Models.RentalStatus;
import com.rental.rentalapplication.Models.User;
import com.rental.rentalapplication.Repository.CartRepository;
import com.rental.rentalapplication.Repository.CompanyRepository;
import com.rental.rentalapplication.Repository.DeviceCartRepository;
import com.rental.rentalapplication.Repository.DeviceRentalRepository;
import com.rental.rentalapplication.Repository.InvoiceRepository;
import com.rental.rentalapplication.Repository.PersonRepository;
import com.rental.rentalapplication.Repository.RentalRepository;
import com.rental.rentalapplication.Repository.UserRepository;
import com.rental.rentalapplication.email.EmailSender;
import com.rental.rentalapplication.email.NewRentalNotification;
import com.rental.rentalapplication.security.SecurityService;

import jakarta.servlet.http.HttpSession;

@Service
public class CartManager {
	
	@Autowired
	private SecurityService securityService;
	
	@Autowired
	private DeviceManager deviceManager;
	
	@Autowired
	private DeviceCartRepository deviceCartRepo;
	
	@Autowired
	private CartRepository cartRepo;

	@Autowired
	private HttpSession httpSession;
	
	@Autowired
	private RentalRepository rentalRepo;
	
	@Autowired
	private DeviceRentalRepository deviceRentalRepo;
	
	@Autowired
	private PersonRepository personRepo;
	
	@Autowired
	private CompanyRepository companyRepo;
	
	@Autowired
	private InvoiceRepository invoiceRepo;
	
	@Autowired
	private UserRepository userRepo;
	
	@Autowired
	private EmailSender emailSender;
	
	@Autowired
	private RentalCost rentalCost;
	
	@Autowired
	private InvoiceGenerator invoiceGenerator;

	
	public void addToCart(@PathVariable Integer id,Authentication authentication) {
		User user=securityService.getUserFromSession(authentication);
		Cart cart =user.getCart();
		
		if(deviceManager.isAvaliable(id)) {
			Device device=deviceManager.getDevice(id);
			DeviceCart deviceCart= new DeviceCart(cart, device);
			cart.addDeviceCart(deviceCart);
			deviceCartRepo.save(deviceCart);
			cartRepo.save(cart);
		}
		
	}
	
	public void deleteDeviceFromCart(@PathVariable("id") Integer id) {
		DeviceCart deviceCart=deviceCartRepo.findById(id).get();
		deviceCartRepo.delete(deviceCart);
	}
	
	public void addToDBFirstStep(@ModelAttribute CartDataDto cartDataDto,Authentication authentication) {
		RentalStatus rentalStatus= new RentalStatus();
		rentalStatus.setId(4);
		User user= securityService.getUserFromSession(authentication);
		Rental rental= new Rental(cartDataDto.getRentalStartDate(),cartDataDto.getRentalEndDate(),rentalStatus,user);
		rentalRepo.save(rental);
		for (DeviceCart deviceCart : user.getCart().getDeviceCart()) {
			
			if(deviceManager.isAvaliable(deviceCart.getDevice().getId())) {
				deviceRentalRepo.save(new DeviceRental(rental, deviceCart.getDevice()));
			}
			
		}
		httpSession.setAttribute("rentalID", rental.getId());
	}
	
	public void addToDbSecondStep(@ModelAttribute CartMetodsDto cartMetodsDto) {
		Integer rentalIdFromSession = (Integer) httpSession.getAttribute("rentalID");
		Rental rental= rentalRepo.findById(rentalIdFromSession).get();
		rental.setMethodOfReception(cartMetodsDto.getMethodsOfReception());
		rental.setMethodOfPayment(cartMetodsDto.getMethodsOfPayment());
		rentalRepo.save(rental);
	}
	
	public void addToDbFourthStep(PersonDto personDto,CompanyDto companyDto,Authentication authentication,@RequestParam("selectedOption") String selectedOption) {
		User user=userRepo.findById(securityService.getUserFromSession(authentication).getId()).get();
		if(selectedOption.equals("person")) {
			Person person=personRepo.findById(securityService.getUserFromSession(authentication).getPerson().getId()).get();
			person.setFirstName(personDto.getFirstName());
			person.setSurname(personDto.getSurname());
			person.setPesel(personDto.getPesel());
			person.setPhoneNumber(personDto.getPhoneNumber());
			person.setPlace(personDto.getPlace());
			person.setHouseNumber(personDto.getHouseNumber());
			person.setStreet(personDto.getStreet());
			person.setZipCode(personDto.getZipCode());
			personRepo.save(person);
		}else {
			if(user.getCompany()==null) {
				Company company=new Company(companyDto.getName(), companyDto.getCompanyNumber(), companyDto.getPlace(), companyDto.getStreet(), companyDto.getBuldingNumber(), companyDto.getZipCode());
				companyRepo.save(company);
				user.setCompany(company);
				userRepo.save(user);
			}else {
				Company company=companyRepo.findById(user.getCompany().getId()).get();
				company.setName(companyDto.getName());
				company.setCompanyNumber(companyDto.getCompanyNumber());
				company.setPlace(companyDto.getPlace());
				company.setStreet(companyDto.getStreet());
				company.setBuldingNumber(companyDto.getBuldingNumber());
				company.setZipCode(companyDto.getZipCode());
				companyRepo.save(company);
			}
		}
		Integer rentalIdFromSession = (Integer) httpSession.getAttribute("rentalID");
		Rental rental=rentalRepo.findById(rentalIdFromSession).get();
		InvoiceType invoiceType=new InvoiceType();
		invoiceType.setId(2);
		invoiceGenerator.generateInvoice(rental, invoiceType, LocalDate.now());
		NewRentalNotification newRental= new NewRentalNotification(user,rental);
		emailSender.send(newRental);
	}
}
