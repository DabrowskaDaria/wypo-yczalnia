package com.rental.rentalapplication.validator;

import java.time.LocalDate;

import com.rental.rentalapplication.DTO.CartDataDto;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class DateValidator implements ConstraintValidator<ValidDate, CartDataDto> {

	@Override
    public void initialize(ValidDate constraintAnnotation) {
    }

	@Override
	public boolean isValid(CartDataDto cartDataDto, ConstraintValidatorContext context) {
        if (cartDataDto.getRentalStartDate() == null || cartDataDto.getRentalEndDate() == null) {
            return true;
        }
        
        boolean isValid = cartDataDto.getRentalStartDate().isBefore(cartDataDto.getRentalEndDate());
        boolean isStartDateValid = cartDataDto.getRentalStartDate().isEqual(LocalDate.now()) || cartDataDto.getRentalStartDate().isAfter(LocalDate.now());
        if (!isValid) {
            context.disableDefaultConstraintViolation();
            context.buildConstraintViolationWithTemplate("Data rozpoczęcia musi być przed datą zakończenia")
                   .addPropertyNode("rentalStartDate")
                   .addConstraintViolation();
            return false;
        }
        
        if (!isStartDateValid) {
            context.disableDefaultConstraintViolation();
            context.buildConstraintViolationWithTemplate("Data rozpoczęcia wypożyczenia musi rozpoczynać się conajmniej dziś")
                   .addPropertyNode("rentalStartDate")
                   .addConstraintViolation();
            return false;
        }

        return true;
    }

}
