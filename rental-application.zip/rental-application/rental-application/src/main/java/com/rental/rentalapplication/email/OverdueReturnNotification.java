package com.rental.rentalapplication.email;

import com.rental.rentalapplication.Models.User;

public class OverdueReturnNotification extends EmailMessage{

	public OverdueReturnNotification(User receiver) {
		super(receiver);
	}

	@Override
	public String content() {
		return "Proszę o jak najszybsze zwrócenie wypożyczenia ";
	}

	@Override
	public String subject() {
		return "Przekroczony termin zwrotu";
	}

}
