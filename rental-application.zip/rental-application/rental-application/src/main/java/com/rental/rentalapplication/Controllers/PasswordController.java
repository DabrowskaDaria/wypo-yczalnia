package com.rental.rentalapplication.Controllers;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.rental.rentalapplication.DTO.PasswordDto;
import com.rental.rentalapplication.Models.User;
import com.rental.rentalapplication.Repository.UserRepository;
import com.rental.rentalapplication.Services.UserManager;
import com.rental.rentalapplication.email.EmailSender;
import com.rental.rentalapplication.email.LinkChangePasswordEmail;
import com.rental.rentalapplication.security.Utility;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;

@Controller
public class PasswordController {

	@Autowired
	private UserRepository userRepo;
		
	@Autowired
	private EmailSender emailSender;
	
	@Autowired
	private UserManager userManager;
	@GetMapping("/changePassword")
	public String changePasswordForm(Model model) {
		model.addAttribute("passwordDto", new PasswordDto());
		return "/password/changePassword";
	}
	
	@PostMapping("/changePassword")
	public String changePassword(Authentication  authentication,@Valid @ModelAttribute PasswordDto passwordDto,BindingResult bindingResult,RedirectAttributes redirectAttributes) {
		if(bindingResult.hasErrors()) {
			return "/password/changePassword";
		}
		userManager.changePassword(authentication, passwordDto, redirectAttributes);
		return "redirect:/changePassword";
	}
	
	@GetMapping("/passwordRecovery")
	public String showRecoveryPasswordForm() {
		return"/login/passwordRecovery";
	}
	
	@PostMapping("/passwordRecovery")
	public String recoveryPassword(HttpServletRequest request, RedirectAttributes redirectAttributes) {
		String email= request.getParameter("email");
		String token=UUID.randomUUID().toString();
		userManager.updateToken(token, email);
		String resetPasswordLink=Utility.getSiteURL(request) + "/resetPassword?token=" + token;
		User user=userRepo.findByEmail(email);
		if(user!=null) {
			LinkChangePasswordEmail linkChangePasswordEmail =new LinkChangePasswordEmail(user,resetPasswordLink);
			emailSender.send(linkChangePasswordEmail);
			redirectAttributes.addFlashAttribute("info", "Wysłano wiadomość email");
		}else {
			redirectAttributes.addFlashAttribute("info", "Wysłano wiadomość email");
		}
		
		return "redirect:/passwordRecovery";
	}
	
	@GetMapping("/resetPassword")
	public String showResetPasswordForm(@Param(value="token")String token,Model model) {
		User user= userManager.getByToken(token);
		model.addAttribute("token", token);
		if(user==null) {
			model.addAttribute("info", "Invalid Token");
		}
		return "/login/resetPasswordForm";
	}
	
	@PostMapping("/resetPassword")
	public String resetPassword(HttpServletRequest request, RedirectAttributes redirectAttributes) {
		String token = request.getParameter("token");
		String password = request.getParameter("password");
		User user= userManager.getByToken(token);
		userManager.updatePassword(user, password);
		redirectAttributes.addFlashAttribute("info", "Zmieniono hasło" );
		return "redirect:/resetPassword?token="+token;
	}
}
