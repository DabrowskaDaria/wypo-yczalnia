package com.rental.rentalapplication.Controllers;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.rental.rentalapplication.DTO.CartDataDto;
import com.rental.rentalapplication.DTO.CartMetodsDto;
import com.rental.rentalapplication.DTO.CartPersonCompanyDto;
import com.rental.rentalapplication.Models.Cart;

import com.rental.rentalapplication.Models.DeviceCart;

import com.rental.rentalapplication.Models.MethodOfPayment;
import com.rental.rentalapplication.Models.MethodOfReception;

import com.rental.rentalapplication.Models.User;
import com.rental.rentalapplication.Repository.CartRepository;

import com.rental.rentalapplication.Repository.MethodOfPaymentRepository;
import com.rental.rentalapplication.Repository.MethodOfReceptionRepository;

import com.rental.rentalapplication.Repository.UserRepository;
import com.rental.rentalapplication.Services.CartManager;

import com.rental.rentalapplication.security.SecurityService;

import jakarta.validation.Valid;


@Controller
public class CartController {
	
	@Autowired
	private CartManager cartManager;
	
	
	@Autowired
	private SecurityService securityService;
	
	@Autowired
	private CartRepository cartRepo;
	
	@Autowired
	private MethodOfReceptionRepository methodOfReceptionRepo;
	
	@Autowired
	private MethodOfPaymentRepository methodOfPaymentRepo;
	
	@Autowired
	private UserRepository userRepo;
	
	
	@GetMapping("/showCart")
	public String showCart(Model model,Authentication authentication) {
		User user=securityService.getUserFromSession(authentication);
		Cart cart=cartRepo.findById(user.getCart().getId()).get();
		List<DeviceCart> devicesCarts= cart.getDeviceCart();
		model.addAttribute("devicesCarts", devicesCarts);
		return "cart/cart";
	}
	
	@PostMapping("/addToCart/{id}")
	public String addToCart(@PathVariable Integer id,@RequestParam("numberOfDevices") Integer numberOfDevices,Authentication authentication) {
		System.out.println(numberOfDevices);
		cartManager.addToCart(id, numberOfDevices, authentication);
		return"redirect:/showDetails/{id}";
	}
	
	@PostMapping("/deleteDeviceFromCart/{id}")
	public String deleteDeviceFromCart(@PathVariable("id") Integer id) {
		cartManager.deleteDeviceFromCart(id);
		return"redirect:/showCart";
	}
	
	@GetMapping("/showCartRentalForm")
	public String showCartRentalForm(Model model) {
		model.addAttribute("cartDataDto", new CartDataDto());
		return "cart/cartFirstStep";
	}
	
	@PostMapping("/addToDBFirstStep")
	public String addToDBFirstStep(@ModelAttribute CartDataDto cartDataDto,Authentication authentication) {
		cartManager.addToDBFirstStep(cartDataDto, authentication);
		return"redirect:/showCartSecondStepForm";
	}
	
	@GetMapping("/showCartSecondStepForm")
	public String showCartSecondStepForm(Model model) {
		List<MethodOfReception> methodsOfReception= methodOfReceptionRepo.findAll();
		List<MethodOfPayment> methodsOfPayment= methodOfPaymentRepo.findAll();
		model.addAttribute("methodsOfReception", methodsOfReception);
		model.addAttribute("methodsOfPayment", methodsOfPayment);
		model.addAttribute("cartMetodsDto", new CartMetodsDto());
		return "cart/cartSecondStep";
	}
	
	@PostMapping("/addToDBSecondStep")
	public String addToDbSecondStep(@ModelAttribute CartMetodsDto cartMetodsDto) {
		cartManager.addToDbSecondStep(cartMetodsDto);
		return "redirect:/showCartThirdStepForm";
	}
	
	@GetMapping("/showCartThirdStepForm")
	public String showCartThirdStepForm(Model model, Authentication  authentication) {
		List<DeviceCart> deviceCart=cartRepo.findById(securityService.getUserFromSession(authentication).getCart().getId()).get().getDeviceCart();
			int totalPrice=0;
			int totalDeposit=0;
			for(DeviceCart dc : deviceCart ) {
				totalPrice+=dc.getDevice().getPrice();
				totalDeposit+=dc.getDevice().getDeposit();
			}
		int totalCosts=totalDeposit + totalPrice;
		model.addAttribute("totalPrice", totalPrice);
		model.addAttribute("totalDeposit", totalDeposit);
		model.addAttribute("totalCosts", totalCosts);
		return "cart/cartThirdStep";
	}
	
	@GetMapping("/showCartFourthStepPage")
	public String showCartFourthStepPage(Model model ) {
		return "cart/cartFourthStep";
	}
	
	@GetMapping("/companyPersonPage")
	public String showCompanyPersonPage(@RequestParam("selectedOption") String selectedOption,Model model,Authentication authentication) {
		User user=userRepo.findById(securityService.getUserFromSession(authentication).getId()).get();
		model.addAttribute("user",user);
		model.addAttribute("cartPersonCompanyDto", new CartPersonCompanyDto());
		model.addAttribute("selectedOption", selectedOption);
		return "cart/companyPersonPage";
	}
	
	
	@PostMapping("/companyPersonPage")
	public String addToDbCompanyOrPerson(@Valid @ModelAttribute CartPersonCompanyDto cartPersonCompanyDto,BindingResult bindingResult,@RequestParam("selectedOption") String selectedOption,Model model,Authentication authentication) {
		User user=securityService.getUserFromSession(authentication);
		model.addAttribute("user", user);
		model.addAttribute("selectedOption", selectedOption);
		if (bindingResult.hasErrors()) {
            return "redirect:/companyPersonPage?selectedOption=" + selectedOption;
        }
		cartManager.addToDbFourthStep(cartPersonCompanyDto, authentication);
		return "redirect:/showCartSummary";
	}
	
	@GetMapping("/showCartSummary")
	public String showCartSummary(Model model) {
		return "cart/summary";
	}
	
}
