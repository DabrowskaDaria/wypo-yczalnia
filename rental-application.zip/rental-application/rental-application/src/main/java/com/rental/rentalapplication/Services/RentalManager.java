package com.rental.rentalapplication.Services;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.rental.rentalapplication.RentalCost;
import com.rental.rentalapplication.DTO.RentalDto;
import com.rental.rentalapplication.Models.DeviceRental;
import com.rental.rentalapplication.Models.Invoice;
import com.rental.rentalapplication.Models.Rental;
import com.rental.rentalapplication.Models.RentalStatus;
import com.rental.rentalapplication.Repository.InvoiceRepository;
import com.rental.rentalapplication.Repository.InvoiceTypeRepository;
import com.rental.rentalapplication.Repository.RentalRepository;
import com.rental.rentalapplication.Repository.RentalStatusRepository;
import com.rental.rentalapplication.email.EmailSender;
import com.rental.rentalapplication.email.OverdueReturnNotification;
import com.rental.rentalapplication.email.ReturnReminderNotification;


@Service
public class RentalManager {
	
	@Autowired
	private RentalRepository rentalRepo;
	
	@Autowired
	private RentalStatusRepository rentalStatusRepo;
	
	
	@Autowired
	private InvoiceTypeRepository invoiceTypeRepo;
	
	@Autowired
	private InvoiceRepository invoiceRepo;
	
	@Autowired
	private EmailSender emailSender;
	
	@Autowired
	private RentalCost rentalCost;

	public void changeRentalStatus(Integer id,RentalDto rentalDto) {
		Rental rental=rentalRepo.findById(id).get();
		rental.setRentalStatus(rentalDto.getRentalStatus());
		rentalRepo.save(rental);
	}
	
	public void rentalCancel(Integer id,RedirectAttributes redirectAttributes ) {
		Rental rental=rentalRepo.findById(id).get();
		if(rental.getRentalStatus().getId()==3 || rental.getRentalStatus().getId()==4) {
			Invoice invoice= new Invoice(LocalDate.now(), 0, 0, invoiceTypeRepo.findById(1).get(), rental);
			RentalStatus rentalStatus=rentalStatusRepo.findById(2).get();
			rental.setRentalStatus(rentalStatus);
			rentalRepo.save(rental);
			invoiceRepo.save(invoice);
			redirectAttributes.addFlashAttribute("info", "Anulowano wypożyczenie");
		}else if(rental.getRentalStatus().getId()==2 || rental.getRentalStatus().getId()==1 || rental.getRentalStatus().getId()==5 || rental.getRentalStatus().getId()==6){
			redirectAttributes.addFlashAttribute("info", "Nie można anulować");
		}		
	}
	
	public void rentalExtend(Integer id, RentalDto rentalDto, RedirectAttributes redirectAttributes) {
		Rental rental=rentalRepo.findById(id).get();
		if(rental.getRentalStatus().getId()==3 || rental.getRentalStatus().getId()==4) {
			Invoice invoice= new Invoice(rentalDto.getRentalEndDate(), rentalCost.calculateTotalPrice(rental), rentalCost.calculateTotalDeposit(rental), invoiceTypeRepo.findById(1).get(), rental);
			rentalRepo.save(rental);
			invoiceRepo.save(invoice);
			redirectAttributes.addFlashAttribute("info", "Przedłużono wypożyczenie");
		}else if(rental.getRentalStatus().getId()==2 || rental.getRentalStatus().getId()==1) {
			redirectAttributes.addFlashAttribute("info", "Nie można anulować");
		}
		rental.setRentalEndDate(rentalDto.getRentalEndDate());
		rentalRepo.save(rental);
	}
	
	@Scheduled(cron = "0 0 8 * * ?")
	public void checkOverdueReturnRental() {
		List<Rental> rentals=rentalRepo.findAll();
		for (Rental rental : rentals) {
			if(LocalDate.now().isAfter(rental.getRentalEndDate()) && rental.getRentalStatus().getName()=="Wypożyczone") {
				OverdueReturnNotification overdueReturnNotification= new OverdueReturnNotification(rental.getUser());
				emailSender.send(overdueReturnNotification);
			}
		}
	}
	
	@Scheduled(cron = "0 38 21 * * ?")
	public void returnReminder() {
		List<Rental> rentals=rentalRepo.findAll();
		
		for (Rental rental : rentals) {
			if(LocalDate.now().isEqual(rental.getRentalEndDate().minusDays(3))&& "Wypożyczone".equals(rental.getRentalStatus().getName()) ) {
				ReturnReminderNotification returnReminderNotification=new ReturnReminderNotification(rental.getUser(),rental);
				emailSender.send(returnReminderNotification);
			}
		}
	}
	
	public Rental showRental(Integer id) {
		return rentalRepo.findById(id).get();
	}
}
