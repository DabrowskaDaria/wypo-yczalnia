package com.rental.rentalapplication.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.rental.rentalapplication.Models.Computer;

@Repository
public interface ComputerRepository extends JpaRepository<Computer, Integer > {
	List<Computer> findByDisplayAndProcessorAndDriveAndRamAndGraphicsCardAndOperatingSystem(String display,String processor,String drive,Integer ram,String graphicsCard,String operatingSystem);
	List<Computer> findByDisplayAndProcessorAndDriveAndRamAndOperatingSystem(String display,String processor,String drive,Integer ram,String operatingSystem);
}
