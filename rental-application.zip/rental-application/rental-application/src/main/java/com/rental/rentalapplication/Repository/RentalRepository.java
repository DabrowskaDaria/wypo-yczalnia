package com.rental.rentalapplication.Repository;


import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.rental.rentalapplication.Models.Rental;

@Repository
public interface RentalRepository  extends JpaRepository<Rental, Integer>{
	List<Rental> findByUserId(Integer id);
	List<Rental> findByUserIdAndRentalStatusId(Integer idUser, Integer idRentalStatus);
	List<Rental> findByRentalEndDate(LocalDate rentalEndDate);
}
