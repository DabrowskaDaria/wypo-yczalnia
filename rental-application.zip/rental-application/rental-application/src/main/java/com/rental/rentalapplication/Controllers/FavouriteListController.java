package com.rental.rentalapplication.Controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.rental.rentalapplication.Models.DeviceFavouriteList;
import com.rental.rentalapplication.Models.FavouriteList;
import com.rental.rentalapplication.Repository.FavouriteListRepository;
import com.rental.rentalapplication.Services.FavouriteListManager;
import com.rental.rentalapplication.security.SecurityService;

@Controller
public class FavouriteListController {
	
	@Autowired
	private SecurityService securityService;
	
	@Autowired
	private FavouriteListRepository favouriteListRepo;
	
	@Autowired
	private FavouriteListManager favouriteListManager;
	
	
	@PostMapping("/addToFavouriteList/{id}")
	public String addToFavouriteList(@PathVariable Integer id,Authentication authentication) {
		favouriteListManager.addToFavouriteList(id, authentication);
		return "redirect:/showDetails/{id}";
	}
	
	@GetMapping("/showFavouriteList")
	public String showFavouriteList(Model model, Authentication authentication) {
		FavouriteList favouriteList= favouriteListRepo.findById(securityService.getUserFromSession(authentication).getFavouriteList().getId()).get();
		List<DeviceFavouriteList> favouritesLists=favouriteList.getDeviceFavouriteLists();
		model.addAttribute("devicesFavouritesLists", favouritesLists);
		return "favouriteList/favouriteList";
	}
	
	@PostMapping("/deleteDevicefromFavouriteList/{id}")
	public String deleteDeviceFromFavouriteList(@PathVariable("id") Integer id) {
		favouriteListManager.deleteDeviceFromFavouriteList(id);
		return"redirect:/showFavouriteList";
	}
}
