package com.rental.rentalapplication.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.rental.rentalapplication.Models.AudioDevice;

@Repository
public interface AudioDeviceRepository extends JpaRepository<AudioDevice, Integer>{
	List<AudioDevice> findBySpeakersPowerAndNumberOfspeakers(String speakersPower,Integer numberOfspeakers);
	List<AudioDevice> findByHeadphoneTypeAndMicrophoneAndWorkingTimeAndWirelessTransmission(String headphoneTyp,Boolean microphone,Integer workingTime,Boolean wirelessTransmission);
	List<AudioDevice> findByFrequencyResponseAndMicrophoneTypeAndWirelessTransmission(String frequencyResponse,String microphoneType,Boolean wirelessTransmission);
}
