package com.rental.rentalapplication.Controllers;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;


import com.rental.rentalapplication.Services.GenerateRentalContractFile;

@Controller
public class ContractController {

	@Autowired
	private GenerateRentalContractFile contractFile;
	
	@GetMapping(value="/downloadContract/{id}",produces = MediaType.APPLICATION_PDF_VALUE)
	public ResponseEntity<byte[]> downloadContract(@PathVariable Integer id ) {
		try {
            byte[] pdf=contractFile.generateContract(id);

            HttpHeaders headers = new HttpHeaders();
            headers.setContentDispositionFormData("attachment", "contract.pdf");

            return ResponseEntity.ok()
                    .headers(headers)
                    .contentType(MediaType.APPLICATION_PDF)
                    .body(pdf);
        } catch (IOException e) {
        	e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
	}
}
