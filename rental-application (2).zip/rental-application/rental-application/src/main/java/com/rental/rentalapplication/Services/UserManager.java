package com.rental.rentalapplication.Services;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.rental.rentalapplication.DTO.EditDataDto;
import com.rental.rentalapplication.DTO.PasswordDto;
import com.rental.rentalapplication.DTO.UserPersonDto;
import com.rental.rentalapplication.Models.AccountType;
import com.rental.rentalapplication.Models.Cart;
import com.rental.rentalapplication.Models.FavouriteList;
import com.rental.rentalapplication.Models.Person;
import com.rental.rentalapplication.Models.User;
import com.rental.rentalapplication.Repository.AccountTypeRepository;
import com.rental.rentalapplication.Repository.CartRepository;
import com.rental.rentalapplication.Repository.CompanyRepository;
import com.rental.rentalapplication.Repository.FavouriteListRepository;
import com.rental.rentalapplication.Repository.PersonRepository;
import com.rental.rentalapplication.Repository.UserRepository;
import com.rental.rentalapplication.email.ChangePasswordEmail;
import com.rental.rentalapplication.email.EmailSender;
import com.rental.rentalapplication.security.SecurityService;

import jakarta.transaction.Transactional;



@Service

public class UserManager {

	@Autowired
	private UserRepository userRepo;
	@Autowired
	private PersonRepository personRepo; 

	@Autowired
	private CartRepository cartRepo;
	
	@Autowired
	private AccountTypeRepository accountTypeRepo;
	
	@Autowired
	private FavouriteListRepository favouriteListRepo;
	
	@Autowired
	private CompanyRepository companyRepo;
	
	@Autowired
	private SecurityService securityService;
	
	@Autowired
	private EmailSender emailSender;
	
	@Transactional
	public void addUser(UserPersonDto userPersonDto, String accountType) {
		BCryptPasswordEncoder passwordEncoder= new BCryptPasswordEncoder();
		User user= new User(userPersonDto.getEmail(),passwordEncoder.encode(userPersonDto.getPassword()),userPersonDto.getAccountType());
		Person person= new Person(userPersonDto.getFirstName(), userPersonDto.getSurname(), userPersonDto.getPhoneNumber());
		if(userPersonDto.getAccountType().getName()=="Użytkownik") {
			Cart cart=new Cart(user);
			cartRepo.save(cart);
			FavouriteList favouriteList= new FavouriteList(user);
			favouriteListRepo.save(favouriteList);
		}
		userRepo.save(user);
		person.setUser(user);
		personRepo.save(person);
		
	}
	
	public List<User> showUsers() {
		List<User> users= userRepo.findAll();
		return users;
	}
	
	@Transactional
	public void deleteUser(Integer id) {
		try {
			User user=userRepo.findById(id).get();
			personRepo.delete(user.getPerson());
			userRepo.delete(user);
			cartRepo.delete(user.getCart());
			favouriteListRepo.delete(user.getFavouriteList());
			if(user.getCompany()!=null) {
				companyRepo.delete(user.getCompany());
			}
		}catch(Exception ex) {
			System.out.println("Exception: " + ex.getMessage());
		}
	}
	
	public void changeData(EditDataDto editDataDto,Authentication  authentication) {
		Person person=securityService.getUserFromSession(authentication).getPerson();
		person.setFirstName(editDataDto.getFirstName());
		person.setSurname(editDataDto.getSurname());
		person.setPhoneNumber(editDataDto.getPhoneNumber());
		personRepo.save(person);
	}
	
	public User getUser(Integer id) {
		return userRepo.findById(id).get();
	}
	
	public List<AccountType> getAllAccountTypes(){
		return accountTypeRepo.findAll();
	}
	
	public void updateToken(String token, String email) throws Exception{
		User user =userRepo.findByEmail(email);
		if(user==null) {
			throw new Exception("Nie znaleziono użytkownika");
		}
		user.setToken(token);
		userRepo.save(user);
	}
	
	public User getByToken(String token) {
		return userRepo.findByToken(token);
	}
	
	public void updatePassword(User user, String newPassword) {
		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
	    String encodedPassword = passwordEncoder.encode(newPassword);
	    user.setPassword(encodedPassword);
	    user.setToken(null);
	    userRepo.save(user);
	}
	
	public void changePassword(Authentication  authentication,PasswordDto passwordDto) {
		User user=securityService.getUserFromSession(authentication);
			BCryptPasswordEncoder passwordEncoder= new BCryptPasswordEncoder();
			user.setPassword(passwordEncoder.encode(passwordDto.getNewPassword()));
			userRepo.save(user);
			ChangePasswordEmail changePasswordEmail=new ChangePasswordEmail(user);
			emailSender.send(changePasswordEmail);
	}
	
	
}
