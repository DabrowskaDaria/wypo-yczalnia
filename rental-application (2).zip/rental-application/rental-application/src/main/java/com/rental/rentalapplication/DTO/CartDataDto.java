package com.rental.rentalapplication.DTO;

import java.time.LocalDate;

import com.rental.rentalapplication.validator.ValidDate;

import jakarta.validation.constraints.NotNull;

@ValidDate
public class CartDataDto {

	
	@NotNull(message="Pole nie może być puste")
	private LocalDate rentalStartDate;
	
	@NotNull(message="Pole nie może być puste")
	private LocalDate rentalEndDate;
	
	public LocalDate getRentalStartDate() {
		return rentalStartDate;
	}

	public void setRentalStartDate(LocalDate rentalStartDate) {
		this.rentalStartDate = rentalStartDate;
	}

	public LocalDate getRentalEndDate() {
		return rentalEndDate;
	}

	public void setRentalEndDate(LocalDate rentalEndDate) {
		this.rentalEndDate = rentalEndDate;
	}

}
