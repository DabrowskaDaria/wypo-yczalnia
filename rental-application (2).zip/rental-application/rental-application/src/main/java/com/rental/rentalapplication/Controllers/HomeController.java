package com.rental.rentalapplication.Controllers;


import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;


import com.rental.rentalapplication.Models.Category;
import com.rental.rentalapplication.Models.Device;
import com.rental.rentalapplication.Services.CategoryManager;
import com.rental.rentalapplication.Services.DeviceManager;

@Controller
public class HomeController {
	
	@Autowired
	private CategoryManager categoryManager;
	
	@Autowired
	private DeviceManager deviceManager;
	
	
	
	@GetMapping({"","/"})
	public String showHomePage(Model model) {
		List<Category> categories=categoryManager.showCategory();
		List<Device> devices=deviceManager.showDevices();
		model.addAttribute("categories", categories);
		model.addAttribute("devices", devices);
		return "homePage/home";
	}
	
	@GetMapping("/homePageForUser")
	public String showHomePageForUser() {
		return "homePage/HomePageForUser";
	}
	
	@GetMapping("/homePageForWorker")
	public String showHomePageForWorker() {
		return "homePage/homePageForWorker";
	}
	
	@GetMapping("/homePageForAdmin")
	public String showHomePageForAdmin() {
		return "homePage/homePageForAdmin";
	}
	
	@GetMapping("/homePageForWarehouseman")
	public String showHomePageForWarehouseman() {
		return "homePage/homePageForWarehouseman";
	}
	
	@GetMapping("/categories/audio")
	public String showCategoryAudio(Model model) {
		
		List<Device> devices=deviceManager.showDevices();
		model.addAttribute("devices", devices);
		return "/homePage/categories/audio/audio";
	}
	
	@GetMapping("/categories/camera")
	public String showCategoryCamera(Model model) {
		List<Device> devices=deviceManager.showDevices();
		model.addAttribute("devices", devices);
		return "/homePage/categories/camera/camera";
	}
	
	@GetMapping("/categories/headphone")
	public String showCategoryHeadphone(Model model) {
		List<Device> devices=deviceManager.showDevices();
		model.addAttribute("devices", devices);
		return "/homePage/categories/headphone/headphone";
	}
	
	@GetMapping("/categories/laptop")
	public String showCategoryLaptop(Model model) {
		List<Device> devices=deviceManager.showDevices();
		model.addAttribute("devices", devices);
		return "/homePage/categories/laptop/laptop";
	}
	@GetMapping("/categories/lighting")
	public String showCategoryLighting(Model model) {
		List<Device> devices=deviceManager.showDevices();
		model.addAttribute("devices", devices);
		return "/homePage/categories/lighting/lighting";
	}
	
	@GetMapping("/categories/microphone")
	public String showCategoryMicrophone(Model model) {
		List<Device> devices=deviceManager.showDevices();
		model.addAttribute("devices", devices);
		return "/homePage/categories/microphone/microphone";
	}
	@GetMapping("/categories/monitor")
	public String showCategoryMonitor(Model model) {
		List<Device> devices=deviceManager.showDevices();
		model.addAttribute("devices", devices);
		return "/homePage/categories/monitor/monitor";
	}
	
	@GetMapping("/categories/projector")
	public String showCategoryprojector(Model model) {
		List<Device> devices=deviceManager.showDevices();
		model.addAttribute("devices", devices);
		return "/homePage/categories/projector/projector";
	}
	@GetMapping("/categories/screen")
	public String showCategoryScreen(Model model) {
		List<Device> devices=deviceManager.showDevices();
		model.addAttribute("devices", devices);
		return "/homePage/categories/screen/screen";
	}
	
	@GetMapping("/categories/tablet")
	public String showCategoryTablet(Model model) {
		List<Device> devices=deviceManager.showDevices();
		model.addAttribute("devices", devices);
		return "/homePage/categories/tablet/tablet";
	}
	
	@GetMapping("/categories/tv")
	public String showCategoryTv(Model model) {
		List<Device> devices=deviceManager.showDevices();
		model.addAttribute("devices", devices);
		return "/homePage/categories/tv/tv";
	}
	
	@GetMapping("/showDetails/{id}")
	public String showDetailsDevice(@PathVariable ("id") Integer id, Model model) {
		Device device=deviceManager.getDevice(id);
		Boolean isAvaliable=deviceManager.isAvaliable(id);
		model.addAttribute("isAvaliable", isAvaliable);
		model.addAttribute("device", device);
		model.addAttribute("deviceConnectors", device.getDeviceConnector());
		return "homePage/deviceDetails";
	}	
	
}
