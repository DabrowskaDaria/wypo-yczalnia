package com.rental.rentalapplication.Services;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

import com.rental.rentalapplication.RentalCost;
import com.rental.rentalapplication.RentalsDays;
import com.rental.rentalapplication.DTO.RentalDto;
import com.rental.rentalapplication.Models.Invoice;
import com.rental.rentalapplication.Models.Rental;
import com.rental.rentalapplication.Models.RentalStatus;
import com.rental.rentalapplication.Models.User;
import com.rental.rentalapplication.Repository.InvoiceRepository;
import com.rental.rentalapplication.Repository.InvoiceTypeRepository;
import com.rental.rentalapplication.Repository.RentalRepository;
import com.rental.rentalapplication.Repository.RentalStatusRepository;
import com.rental.rentalapplication.Repository.UserRepository;
import com.rental.rentalapplication.email.EmailSender;
import com.rental.rentalapplication.email.OverdueReturnNotification;
import com.rental.rentalapplication.email.ReturnReminderNotification;
import com.rental.rentalapplication.security.SecurityService;


@Service
public class RentalManager {
	
	@Autowired
	private RentalRepository rentalRepo;
	
	@Autowired
	private RentalStatusRepository rentalStatusRepo;
	
	
	@Autowired
	private InvoiceTypeRepository invoiceTypeRepo;
	
	@Autowired
	private InvoiceRepository invoiceRepo;
	
	@Autowired
	private EmailSender emailSender;
	
	@Autowired
	private RentalCost rentalCost;
	
	@Autowired
	private UserRepository userRepo;
	
	@Autowired
	private SecurityService securityService;
	
	public void changeRentalStatus(Integer id,RentalDto rentalDto) {
		Rental rental=rentalRepo.findById(id).get();
		rental.setRentalStatus(rentalDto.getRentalStatus());
		rentalRepo.save(rental);
	}
	
	public List<RentalStatus> showRentalStatus() {
		List<RentalStatus> rentalStatuses=new ArrayList<RentalStatus>();
		rentalStatuses.add(rentalStatusRepo.findById(3).get());
		rentalStatuses.add(rentalStatusRepo.findById(5).get());
		return rentalStatuses;
	}
	
	public List<Rental> showRentalsForWarehouseman(){
		List<Rental> rentals1= rentalRepo.findAll();
		List<Rental> rentals= new ArrayList<Rental>();
		for (Rental rental : rentals1) {
			if(rental.getRentalStatus().getId()==4 || rental.getRentalStatus().getId()==3) {
				rentals.add(rental);
			}
		}
		return rentals;
	}
	
	public void rentalCancel(Integer id) throws Exception{
		Rental rental=rentalRepo.findById(id).get();
		if(rental.getRentalStatus().getId()==3 || rental.getRentalStatus().getId()==4) {
			Invoice invoice= new Invoice(LocalDate.now(), 0, 0, invoiceTypeRepo.findById(1).get(), rental);
			rental.setRentalStatus(rentalStatusRepo.findById(2).get());
			rentalRepo.save(rental);
			invoiceRepo.save(invoice);
		}else if(rental.getRentalStatus().getId()==2 || rental.getRentalStatus().getId()==1 || rental.getRentalStatus().getId()==5 || rental.getRentalStatus().getId()==6){
			throw new Exception("Nie można anulować ");
		}		
	}
	
	public void rentalExtend(Integer id, RentalDto rentalDto) throws Exception {
		Rental rental=rentalRepo.findById(id).get();
		if(rental.getRentalStatus().getId()==3 || rental.getRentalStatus().getId()==4 || rental.getRentalStatus().getId()==5 || rental.getRentalStatus().getId()==6) {
			Invoice invoice= new Invoice(rentalDto.getRentalEndDate(), rentalCost.calculateTotalPrice(rental), rentalCost.calculateTotalDeposit(rental), invoiceTypeRepo.findById(1).get(), rental);
			rental.setRentalEndDate(rentalDto.getRentalEndDate());
			rentalRepo.save(rental);
			invoiceRepo.save(invoice);
			
		}else if(rental.getRentalStatus().getId()==2 || rental.getRentalStatus().getId()==1) {
			throw new Exception("Nie można przedłużyć wypożyczenia ");
		}
	}
	
	@Scheduled(cron = "0 0 8 * * ?")
	public void checkOverdueReturnRental() {
		List<Rental> rentals=rentalRepo.findAll();
		for (Rental rental : rentals) {
			if(LocalDate.now().isAfter(rental.getRentalEndDate()) && rental.getRentalStatus().getName()=="Wypożyczone") {
				OverdueReturnNotification overdueReturnNotification= new OverdueReturnNotification(rental.getUser());
				emailSender.send(overdueReturnNotification);
			}
		}
	}
	
	@Scheduled(cron = "0 0 10 * * ?")
	public void returnReminder() {
		List<Rental> rentals=rentalRepo.findAll();
		for (Rental rental : rentals) {
			if(LocalDate.now().isEqual(rental.getRentalEndDate().minusDays(3))&& "Wypożyczone".equals(rental.getRentalStatus().getName()) ) {
				ReturnReminderNotification returnReminderNotification=new ReturnReminderNotification(rental.getUser(),rental);
				emailSender.send(returnReminderNotification);
			}
		}
	}
	
	public Rental showRental(Integer id) {
		return rentalRepo.findById(id).get();
	}
	
	public List<Rental> showCurrentRentals(Authentication authentication) {
		User user=userRepo.findById(securityService.getUserFromSession(authentication).getId()).get();
		List<Rental> rentals= rentalRepo.findByUserId(user.getId());
		List<Rental> currentRentals=new ArrayList<Rental>();
		for (Rental rental : rentals) {
			if(rental.getRentalStatus().getName().equals("Nowe") || rental.getRentalStatus().getName().equals("W trakcie przygotowania") || rental.getRentalStatus().getName().equals("Gotowe do odbioru") || rental.getRentalStatus().getName().equals("Wypożyczone") ) {
				currentRentals.add(rental);
			}
		}
		return currentRentals;
	}
	
	public List<Rental> historyRentals(Authentication authentication) {
		User user=userRepo.findById(securityService.getUserFromSession(authentication).getId()).get();
		Integer userID=user.getId();
		List<Rental> rentals1= rentalRepo.findByUserIdAndRentalStatusId(userID, 1);
		List<Rental> rentals2= rentalRepo.findByUserIdAndRentalStatusId(userID, 2);
		List<Rental> rentals= new ArrayList<Rental>(rentals1);
		rentals.addAll(rentals2);
		return rentals;
	}
	
	public List<RentalsDays> showNotReturnedRentals() {
		List<Rental> rentals= rentalRepo.findAll();
		List<RentalsDays> notReturnedRentals= new ArrayList<>();
		
		LocalDate now= LocalDate.now();
		for (Rental rental : rentals) {
			LocalDate endDate= rental.getRentalEndDate();
			if(endDate.isBefore(now) && rental.getRentalStatus().getId()==6) {
				Long days=ChronoUnit.DAYS.between(endDate, now);
				notReturnedRentals.add(new RentalsDays(rental, days));
			}
		}
		for (RentalsDays rentalsDays : notReturnedRentals) {
			rentalsDays.getRental();
		}
		return notReturnedRentals;
	}
	
	public List<Rental> showCurrentlyRentedDevices() {
		List<Rental> rentals=rentalRepo.findAll();
		List<Rental> currentRentals= new ArrayList<Rental>();
		
		for (Rental rental : rentals) {
			if(rental.getRentalStatus().getId()==3 || rental.getRentalStatus().getId()==4 || rental.getRentalStatus().getId()==5 || rental.getRentalStatus().getId()==6 ) {
				currentRentals.add(rental);
			}
		}
		for (Rental currentRental : currentRentals) {
			currentRental.getDeviceRentals();
		}
		return currentRentals;
	}
}
