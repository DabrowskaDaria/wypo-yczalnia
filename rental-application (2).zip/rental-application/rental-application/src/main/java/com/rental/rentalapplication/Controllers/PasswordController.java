package com.rental.rentalapplication.Controllers;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.rental.rentalapplication.DTO.EmailDto;
import com.rental.rentalapplication.DTO.PasswordDto;
import com.rental.rentalapplication.Models.User;
import com.rental.rentalapplication.Repository.UserRepository;
import com.rental.rentalapplication.Services.UserManager;
import com.rental.rentalapplication.email.EmailSender;
import com.rental.rentalapplication.email.LinkChangePasswordEmail;
import com.rental.rentalapplication.security.Utility;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;

@Controller
public class PasswordController {

	@Autowired
	private UserRepository userRepo;
		
	@Autowired
	private EmailSender emailSender;
	
	@Autowired
	private UserManager userManager;
	@GetMapping("/changePassword")
	public String changePasswordForm(Model model) {
		model.addAttribute("passwordDto", new PasswordDto());
		return "/password/changePassword";
	}
	
	@PostMapping("/changePassword")
	public String changePassword(Authentication  authentication,@Valid @ModelAttribute PasswordDto passwordDto,BindingResult bindingResult) {
		if(bindingResult.hasErrors()) {
			return "/password/changePassword";
		}
		userManager.changePassword(authentication, passwordDto);
		return "redirect:/changePassword";
	}
	
	@GetMapping("/passwordRecovery")
	public String showRecoveryPasswordForm(Model model) {
		model.addAttribute("emailDto", new EmailDto());
		return"/login/passwordRecovery";
	}
	
	@PostMapping("/passwordRecovery")
	public String recoveryPassword(@Valid @ModelAttribute EmailDto emailDto,BindingResult bindingResult, 
			HttpServletRequest request, RedirectAttributes redirectAttributes) throws Exception {
		if(bindingResult.hasErrors()) {
			return "/login/passwordRecovery";
		}
		String email= emailDto.getEmail();
		String token=UUID.randomUUID().toString();
		try {userManager.updateToken(token, email);}catch(Exception e){}
		
		String resetPasswordLink=Utility.getSiteURL(request) + "/resetPassword?token=" + token;
		User user=userRepo.findByEmail(email);
		if(user!=null) {
			LinkChangePasswordEmail linkChangePasswordEmail =new LinkChangePasswordEmail(user,resetPasswordLink);
			emailSender.send(linkChangePasswordEmail);
			redirectAttributes.addFlashAttribute("info", "Wysłano wiadomość email");
		}else {
			redirectAttributes.addFlashAttribute("info", "Wysłano wiadomość email");
		}
		
		return "redirect:/passwordRecovery";
	}
	
	@GetMapping("/resetPassword")
	public String showResetPasswordForm(@Param(value="token")String token,Model model) {
		User user= userManager.getByToken(token);
		model.addAttribute("passwordDto", new PasswordDto());
		model.addAttribute("token", token);
		if(user==null) {
			model.addAttribute("info", "Invalid Token");
		}
		return "/login/resetPasswordForm";
	}
	
	@GetMapping("/resetPasswordSuccessPage")
	public String showSuccesPage() {
		
		return "/password/resetPasswordSucess";
	}
	
	@PostMapping("/resetPassword")
	public String resetPassword(Model model,@Valid @ModelAttribute PasswordDto passwordDto,BindingResult bindingResult, 
			HttpServletRequest request, RedirectAttributes redirectAttributes) {
		String token = request.getParameter("token");
		if(bindingResult.hasErrors()) {
			model.addAttribute("token", token);
			return "/login/resetPasswordForm";
		}
		
		User user= userManager.getByToken(token);
		String password = passwordDto.getRepeatedPassword();
			
		userManager.updatePassword(user, password);
		redirectAttributes.addFlashAttribute("info", "Zmieniono hasło" );
		
		
		return "redirect:/resetPasswordSuccessPage";
	}
}
