package com.rental.rentalapplication.Controllers;


import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.rental.rentalapplication.RentalsDays;

import com.rental.rentalapplication.DTO.RentalDto;
import com.rental.rentalapplication.Models.Rental;
import com.rental.rentalapplication.Models.RentalStatus;
import com.rental.rentalapplication.Repository.RentalRepository;
import com.rental.rentalapplication.Repository.RentalStatusRepository;
import com.rental.rentalapplication.Services.RentalManager;

@Controller
public class RentalController {

	@Autowired
	private RentalRepository rentalRepo;
	
	@Autowired
	private RentalStatusRepository rentalStatusRepo;
	
	@Autowired
	private RentalManager rentalManager;
	
	@GetMapping("/showRentals")
	public String showRentals(Model model) {
		List<Rental> rentals= rentalRepo.findAll();
		model.addAttribute("rentals", rentals);
		return "rental/showRentals";
	}
	
	@GetMapping("/changeStatus/{id}")
	public String changeStatusForm(@PathVariable("id") Integer id,Model model) {
		Rental rental=rentalRepo.findById(id).get();
		List<RentalStatus> rentalStatuses=rentalStatusRepo.findAll();
		model.addAttribute("rental", rental);
		model.addAttribute("rentalStatuses", rentalStatuses);
		model.addAttribute("rentalDto", new RentalDto());
		return "rental/changeStatus";
	}
	
	@PostMapping("/changeStatus/{id}")
	public String changeStatus(@PathVariable("id") Integer id, @ModelAttribute RentalDto rentalDto) {
		rentalManager.changeRentalStatus(id, rentalDto);
		return"redirect:/showRentals";
	}
	
	@GetMapping("/showRentalsForWarehouseman")
	public String showRentalsforWarehouseman(Model model) {
		List<Rental> rentals=rentalManager.showRentalsForWarehouseman();
		model.addAttribute("rentals", rentals);
		return "rental/showRentalsForWarehouseman";
	}
	
	@GetMapping("/warehousemanChangeStatus/{id}")
	public String warehousemanChangesStatusForm(@PathVariable("id") Integer id,Model model) {
		Rental rental=rentalRepo.findById(id).get();
		List<RentalStatus> rentalStatuses=rentalManager.showRentalStatus();
		model.addAttribute("rental", rental);
		model.addAttribute("rentalStatuses", rentalStatuses);
		model.addAttribute("rentalDto", new RentalDto());
		return "rental/changeStatusWarehouseman";
	}
	
	
	
	@PostMapping("/warehousemanChangeStatus/{id}")
	public String warehousemanChangesStatus(@PathVariable("id") Integer id, @ModelAttribute RentalDto rentalDto) {
		rentalManager.changeRentalStatus(id, rentalDto);
		return"redirect:/showRentalsForWarehouseman";
	}
	
	
	
	@GetMapping("/currentRentals")
	public String showCurrentRentals(Model model,Authentication authentication) {
		List<Rental> currentRentals=rentalManager.showCurrentRentals(authentication);
		model.addAttribute("rentals", currentRentals);
		return "rental/currentRentals";
	}
	
	@PostMapping("/cancelRental/{id}")
	public String cancelRental(@PathVariable ("id") Integer id,RedirectAttributes redirectAttributes ) {
		try {
			rentalManager.rentalCancel(id);
			redirectAttributes.addFlashAttribute("info", "Anulowano wypożyczenie");
		}catch(Exception exception) {
			redirectAttributes.addFlashAttribute("info", "Nie można anulować wypożyczenia");
		}
		return"redirect:/currentRentals";
	}
	
	@GetMapping("/historyRentals")
	public String showHistoryRentals(Model model,Authentication authentication) {
		List<Rental> rentals= rentalManager.historyRentals(authentication);
		model.addAttribute("rentals", rentals);
		return "rental/historyRentals";
	}
	
	@GetMapping("/notReturned")
	public String showNotReturnedRentals(Model model) {
		List<RentalsDays> notReturnedRentals= rentalManager.showNotReturnedRentals();
		model.addAttribute("notReturnedRentals", notReturnedRentals);
		return "rental/notReturnedRentals";
	}
	
	@GetMapping("/extendRental/{id}")
	public String showExtendRentalForm(@PathVariable ("id") Integer id,Model model) {
		Rental rental=rentalRepo.findById(id).get();
		model.addAttribute("rental", rental);
		return"rental/extendRental";
	}
	
	@PostMapping("/extendRental/{id}")
	public String extendRental(@PathVariable ("id") Integer id,@ModelAttribute RentalDto rentalDto, RedirectAttributes redirectAttributes) {
		try {
			rentalManager.rentalExtend(id, rentalDto);
			redirectAttributes.addFlashAttribute("info", "Przedłużono wypożyczenie");
		}catch(Exception exception) {
			redirectAttributes.addFlashAttribute("info", "Nie można przedłużyć wypożyczenia");
		}
		return"redirect:/currentRentals";
	}
	
	@GetMapping("/rentalDetails/{id}")
	public String showRentalDetails(@PathVariable ("id") Integer id,Model model) {
		Rental rental=rentalManager.showRental(id);
		model.addAttribute("rentalDevices", rental.getDeviceRentals());
		return"rental/rentalDetails";
	}
	
	@GetMapping("/currentlyRentedDevices")
	public String showCurrentlyRentedDevices(Model model) {
		List<Rental> currentRentals= rentalManager.showCurrentlyRentedDevices();
		model.addAttribute("currentRentals", currentRentals);
		return"rental/curentlyRentedDevices";
	}
	
}
