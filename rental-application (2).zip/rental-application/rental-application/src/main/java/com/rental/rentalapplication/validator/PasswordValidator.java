package com.rental.rentalapplication.validator;


import com.rental.rentalapplication.DTO.PasswordDto;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class PasswordValidator implements ConstraintValidator<ValidPassword, PasswordDto>{

	@Override
    public void initialize(ValidPassword constraintAnnotation) {
    }
	
	@Override
	public boolean isValid(PasswordDto passwordDto, ConstraintValidatorContext context) {
		 if (passwordDto.getNewPassword() == null || passwordDto.getRepeatedPassword() == null) {
	            return false;
	        }
	        boolean isValid = passwordDto.getNewPassword().equals(passwordDto.getRepeatedPassword());
	        if (!isValid) {
	            context.disableDefaultConstraintViolation();
	            context.buildConstraintViolationWithTemplate("Hasła muszą być takie same")
	                   .addPropertyNode("repeatedPassword")
	                   .addConstraintViolation();
	        }
	        return isValid;
    }
     
}
