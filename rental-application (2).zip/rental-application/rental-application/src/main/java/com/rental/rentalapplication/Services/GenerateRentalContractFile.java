package com.rental.rentalapplication.Services;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aspose.pdf.BorderInfo;
import com.aspose.pdf.BorderSide;
import com.aspose.pdf.Color;
import com.aspose.pdf.Document;
import com.aspose.pdf.FontRepository;
import com.aspose.pdf.Page;
import com.aspose.pdf.Row;
import com.aspose.pdf.Table;
import com.aspose.pdf.TextFragment;
import com.aspose.pdf.TextState;
import com.rental.rentalapplication.Models.Device;
import com.rental.rentalapplication.Models.DeviceRental;
import com.rental.rentalapplication.Models.Rental;
import com.rental.rentalapplication.Repository.RentalRepository;

@Service
public class GenerateRentalContractFile {

	@Autowired
	private RentalRepository rentalRepo;
	
	public byte[] generateContract(Integer id) throws IOException{
		Rental rental=rentalRepo.findById(id).get();
		Document document = new Document();
		Page page=document.getPages().add();
		TextState textState = new TextState();
        textState.setFont(FontRepository.findFont("Times New Roman"));
        textState.setFontSize(12);
		page.getPageInfo().setDefaultTextState(textState);
		
		page.getParagraphs().add(new TextFragment("Umowa wypożyczenia"));
		if("Anulowane".equals(rental.getRentalStatus().getName())) {
			page.getParagraphs().add(new TextFragment("Wypożyczenie zostało anulowane"));
		}
		page.getParagraphs().add(new TextFragment("Data wypożyczenia: "+rental.getRentalStartDate()));
		page.getParagraphs().add(new TextFragment("Data zwrotu: "+rental.getRentalEndDate()));
		page.getParagraphs().add(new TextFragment("Metoda płatności: "+rental.getMethodOfPayment().getName()));
		page.getParagraphs().add(new TextFragment("Sposób dostawy: "+rental.getMethodOfReception().getName()));
		page.getParagraphs().add(new TextFragment("Dane wypożyczającego: "));
		if(rental.getUser().getCompany()==null) {
			page.getParagraphs().add(new TextFragment("Imię i nazwisko: "+rental.getUser().getPerson().getFirstName()+" "+rental.getUser().getPerson().getSurname()));
			page.getParagraphs().add(new TextFragment("Numer telefonu: "+rental.getUser().getPerson().getPhoneNumber()));
			page.getParagraphs().add(new TextFragment("Pesel: "+ rental.getUser().getPerson().getPesel()));
			page.getParagraphs().add(new TextFragment("Adres: "
					+rental.getUser().getPerson().getPlace()+" ul. "
					+rental.getUser().getPerson().getStreet()+ " "
					+rental.getUser().getPerson().getHouseNumber()+" "
					+rental.getUser().getPerson().getZipCode()));
			
		}else {
			
			page.getParagraphs().add(new TextFragment("Nazwa firmy: "+rental.getUser().getCompany().getName()));
			page.getParagraphs().add(new TextFragment("Nip: "+rental.getUser().getCompany().getCompanyNumber()));
			page.getParagraphs().add(new TextFragment("Adres: "
					+rental.getUser().getCompany().getPlace()+" ul. "
					+rental.getUser().getCompany().getStreet()+ " "
					+rental.getUser().getCompany().getBuldingNumber()+" "
					+rental.getUser().getCompany().getZipCode()));
		}
		List<Device> devices=new ArrayList<Device>();
		for (DeviceRental  deviceRental: rental.getDeviceRentals()) {
			devices.add(deviceRental.getDevice());
		}
		page.getParagraphs().add(new TextFragment("Wypożyczone urządzenia: "));
		
		
		Table table= new Table();
		table.setBorder(new BorderInfo(BorderSide.All, .5f, Color.getBlack()));
		table.setDefaultCellBorder(new BorderInfo(BorderSide.All, 0.5f, Color.getBlack()));
		Row headerRow= table.getRows().add();
		headerRow.getCells().add("ID");
		headerRow.getCells().add("Nazwa");
		headerRow.getCells().add("Cena [zł]");
		headerRow.getCells().add("Kaucja [zł]");
		Integer i=1;
		for (Device device : devices) {
			Row row= table.getRows().add();
			row.getCells().add(String.valueOf(i));
            row.getCells().add(device.getName());
            row.getCells().add(String.valueOf(device.getPrice()));
            row.getCells().add(String.valueOf(device.getDeposit()));
			i++;
		}
		page.getParagraphs().add(table);
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        document.save(outputStream);
        document.close();
        return outputStream.toByteArray();

	}
}
