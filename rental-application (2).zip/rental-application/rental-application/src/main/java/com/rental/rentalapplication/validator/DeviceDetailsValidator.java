package com.rental.rentalapplication.validator;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import com.rental.rentalapplication.DTO.DeviceDto;
import com.rental.rentalapplication.Repository.CategoryRepository;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class DeviceDetailsValidator implements ConstraintValidator<ValidDeviceDetails,DeviceDto>{
	
	@Autowired
	private CategoryRepository categoryRepo;
	
	@Override
    public void initialize(ValidDeviceDetails constraintAnnotation) {
        
    }
	
	@Override
	public boolean isValid(DeviceDto deviceDto, ConstraintValidatorContext context) {
		if(deviceDto==null) {
			return true;
		}
		
		String category=categoryRepo.findById(deviceDto.getSelectedCategory()).get().getName();
		Map<String, String> deviceDetails=deviceDto.getTechnicalDetails();
		
		if("telewizor".equals(category)) {
			return validateTV(deviceDetails,context);
		}
		
		return true;
	}
	
	private boolean validateTV(Map<String, String> deviceDetails, ConstraintValidatorContext context) {
    boolean isValid = true;
    
    if(deviceDetails.containsKey("screenSize") || deviceDetails.get("screenSize").isEmpty()) {
    	isValid = false;
    	context.disableDefaultConstraintViolation();
        context.buildConstraintViolationWithTemplate("Pole rozmiar ekranu jest wymagane")
               .addPropertyNode("technicalDetails['screenSize']")
               .addConstraintViolation();
    	
    }
    
    return isValid;
    
    }
}
