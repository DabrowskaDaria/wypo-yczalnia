package com.rental.rentalapplication.Services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.rental.rentalapplication.Models.Device;
import com.rental.rentalapplication.Models.DeviceRental;
import com.rental.rentalapplication.Models.Invoice;

@Service
public class InvoiceManager {

	
	public List<Device> getDeviceFromInvoice(Invoice invoice){
		List<Device> devices=new ArrayList<Device>();
		for (DeviceRental deviceRental : invoice.getRental().getDeviceRentals()) {
			devices.add(deviceRental.getDevice());
		}
		return devices;
	}
}
