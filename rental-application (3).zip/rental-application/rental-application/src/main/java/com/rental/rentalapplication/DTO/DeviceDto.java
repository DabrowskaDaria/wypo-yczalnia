package com.rental.rentalapplication.DTO;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.rental.rentalapplication.Models.Connector;
import com.rental.rentalapplication.validator.ValidDeviceDetails;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;


@ValidDeviceDetails(groups = {DeviceDto.Add.class, DeviceDto.Modify.class})
public class DeviceDto {
	
	public interface Add {}
	
	public interface Modify {}
	
	@NotBlank(message="Pole nie może być puste",groups = {Add.class, Modify.class})
	private String name;
	
	@NotNull(message="Pole nie może być puste" ,groups = {Add.class, Modify.class})
	private Integer price;
	
	@NotNull(message="Pole nie może być puste" ,groups = {Add.class, Modify.class})
	private Integer deposit;
	
	@NotBlank(message="Pole nie może być puste" ,groups = {Add.class, Modify.class})
	@Size(min=10,message="Opis musi zawierać co najmniej 10 znaków" ,groups = {Add.class, Modify.class})
	private String description;

	@NotEmpty(message = "Opcja musi być zaznaczona",groups = {Add.class})
	private List<Connector> connectors=new ArrayList<Connector>();
	
	
	private Integer selectedCategory;
	
	private Connector connector;
	
	private Map<String, String> technicalDetails= new HashMap<String, String>();
	
	
	public String getScreenSize() {
		return technicalDetails.get("screenSize");
	}
	
	public String getSpeakersPower() {
		return technicalDetails.get("speakersPower");
	}

	public Integer getNumberOfspeakers() {
		
		String numberOfspeakers = technicalDetails.get("numberOfspeakers");
	    try {
	        return Integer.parseInt(numberOfspeakers);
	    } catch (NumberFormatException e) {
	        return null;
	    }
	}

	public String getFrequencyResponse() {
		return technicalDetails.get("frequencyResponse");
	}

	public String getMicrophoneType() {
		return technicalDetails.get("microphoneType");
	}

	public String getHeadphoneType() {
		return technicalDetails.get("headphoneType");
	}

	public Boolean isMicrophone() {
	    return Boolean.valueOf(technicalDetails.get("microphone")); 
	    
	}

	public Integer getWorkingTime() {
		
		String workingTime = technicalDetails.get("workingTime");
	    try {
	        return Integer.parseInt(workingTime);
	    } catch (NumberFormatException e) {
	        return null;
	    }
	}

	public Boolean isWirelessTransmission() {
		
		return Boolean.valueOf(technicalDetails.get("wirelessTransmission")); 
	}

	public String getResolution() {
		return technicalDetails.get("resolution");
	}

	public Boolean isImageStabilization() {
	    return Boolean.valueOf(technicalDetails.get("imageStabilization")); 
	    
	}

	public Boolean isOpticalZoom() {
		
	    return Boolean.valueOf(technicalDetails.get("opticalZoom")); 
	   
	}

	public String getDisplay() {
		return technicalDetails.get("display");
	}

	public String getProcessor() {
		return technicalDetails.get("processor");
	}

	public String getDrive() {
		return technicalDetails.get("drive");
	}

	public String getGraphicsCard() {
		return technicalDetails.get("graphicsCard");
	}

	public String getLightingColor() {
		return technicalDetails.get("lightingColor");
	}

	public Integer getPowerConsumption() {
		
		String powerConsumption = technicalDetails.get("powerConsumption");
	    try {
	        return Integer.parseInt(powerConsumption);
	    } catch (NumberFormatException e) {
	        return null;
	    }
	}

	public String getDeviceSize() {
		return technicalDetails.get("deviceSize");
	}

	public Integer getRefreshRate() {
		String refreshRate = technicalDetails.get("refreshRate");
	    try {
	        return Integer.parseInt(refreshRate);
	    } catch (NumberFormatException e) {
	        return null;
	    }
	}
	
	public String getScreenFormat() {
		return technicalDetails.get("screenFormat");
	}
	
	public String getActiveSurface() {
		return technicalDetails.get("activeSurface");
	}
	
	public String getMatrixType() {
		return technicalDetails.get("matrixType");
	}
	
	public Integer getLampPower() {
		
		String lampPower = technicalDetails.get("lampPower");
	    try {
	        return Integer.parseInt(lampPower);
	    } catch (NumberFormatException e) {
	        return null;
	    }
	}
	
	public String getScreenResolution() {
		return technicalDetails.get("screenResolution");
	}
	
	
	public Map<String, String> getTechnicalDetails() {
		return technicalDetails;
	}

	public Connector getConnector() {
		return connector;
	}

	public void setConnector(Connector connector) {
		this.connector = connector;
	}


	public void setName(String name) {
		this.name = name;
	}

	public void setPrice(Integer price) {
		this.price = price;
	}

	public void setDeposit(Integer deposit) {
		this.deposit = deposit;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	
	public String getName() {
		return name;
	}
	
	public Integer getPrice() {
		return price;
	}
	
	public Integer getDeposit() {
		return deposit;
	}
	
	public String getDescription() {
		return description;
	}

	public List<Connector> getConnectors() {
		return connectors;
	}

	public void setConnectors(List<Connector> connectors) {
		this.connectors = connectors;
	}

	public void setTechnicalDetails(Map<String, String> technicalDetails) {
		this.technicalDetails = technicalDetails;
	}


	public Integer getRam() {
		String ram = technicalDetails.get("ram");
	    try {
	        return Integer.parseInt(ram);
	    } catch (NumberFormatException e) {
	        return null;
	    }
	}

	public String getOperatingSystem() {
		return technicalDetails.get("operatingSystem");
	}


	public Integer getSelectedCategory() {
		return selectedCategory;
	}

	public void setSelectedCategory(Integer selectedCategory) {
		this.selectedCategory = selectedCategory;
	}

}
