package com.rental.rentalapplication.Controllers;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.rental.rentalapplication.RentalCost;
import com.rental.rentalapplication.DTO.CartDataDto;
import com.rental.rentalapplication.DTO.CartMetodsDto;
import com.rental.rentalapplication.DTO.CompanyDto;
import com.rental.rentalapplication.DTO.PersonDto;
import com.rental.rentalapplication.Models.Cart;

import com.rental.rentalapplication.Models.DeviceCart;

import com.rental.rentalapplication.Models.MethodOfPayment;
import com.rental.rentalapplication.Models.MethodOfReception;
import com.rental.rentalapplication.Models.Rental;
import com.rental.rentalapplication.Models.User;
import com.rental.rentalapplication.Repository.CartRepository;

import com.rental.rentalapplication.Repository.MethodOfPaymentRepository;
import com.rental.rentalapplication.Repository.MethodOfReceptionRepository;
import com.rental.rentalapplication.Repository.RentalRepository;
import com.rental.rentalapplication.Repository.UserRepository;
import com.rental.rentalapplication.Services.CartManager;
import com.rental.rentalapplication.Services.DeviceManager;
import com.rental.rentalapplication.security.SecurityService;

import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;


@Controller
public class CartController {
	
	@Autowired
	private CartManager cartManager;
		
	@Autowired
	private SecurityService securityService;
	
	@Autowired
	private CartRepository cartRepo;
	
	@Autowired
	private MethodOfReceptionRepository methodOfReceptionRepo;
	
	@Autowired
	private MethodOfPaymentRepository methodOfPaymentRepo;
	
	@Autowired
	private UserRepository userRepo;
	
	@Autowired
	private DeviceManager deviceManager;
	
	@Autowired
	private HttpSession httpSession;
	
	@Autowired
	private RentalRepository rentalRepo;
	
	@Autowired
	private RentalCost rentalCost;
	
	
	@GetMapping("/showCart")
	public String showCart(Model model,Authentication authentication) {
		User user=securityService.getUserFromSession(authentication);
		Cart cart=cartRepo.findById(user.getCart().getId()).get();
		List<DeviceCart> devicesCarts= cart.getDeviceCart();
		
		Boolean allDevicesNotAvaliable=cartManager.showCart(authentication);
		Integer cost=rentalCost.calculateCostPerDay(devicesCarts);
		model.addAttribute("devicesCarts", devicesCarts);
		model.addAttribute("cost", cost);
		model.addAttribute("allDevicesNotAvaliable", allDevicesNotAvaliable);
		return "cart/cart";
	}
	
	@PostMapping("/addToCart/{id}")
	public String addToCart(@PathVariable Integer id,Authentication authentication) {
		if(deviceManager.isAvaliable(id)==true) {
			cartManager.addToCart(id, authentication);
		}
		return"redirect:/showDetails/{id}";
	}
	
	@PostMapping("/deleteDeviceFromCart/{id}")
	public String deleteDeviceFromCart(@PathVariable("id") Integer id) {
		cartManager.deleteDeviceFromCart(id);
		return"redirect:/showCart";
	}
	
	@GetMapping("/showCartRentalForm")
	public String showCartRentalForm(Model model) {
		model.addAttribute("cartDataDto", new CartDataDto());
		return "cart/cartFirstStep";
	}
	
	@PostMapping("/addToDBFirstStep")
	public String addToDBFirstStep(@Valid @ModelAttribute CartDataDto cartDataDto,BindingResult bindingResult,Authentication authentication) {
		if(bindingResult.hasErrors()) {
			return"cart/cartFirstStep";
		}
		cartManager.addToDBFirstStep(cartDataDto, authentication);
		return"redirect:/showCartSecondStepForm";
	}
	
	@GetMapping("/showCartSecondStepForm")
	public String showCartSecondStepForm(Model model) {
		List<MethodOfReception> methodsOfReception= methodOfReceptionRepo.findAll();
		List<MethodOfPayment> methodsOfPayment= methodOfPaymentRepo.findAll();
		model.addAttribute("methodsOfReception", methodsOfReception);
		model.addAttribute("methodsOfPayment", methodsOfPayment);
		model.addAttribute("cartMetodsDto", new CartMetodsDto());
		return "cart/cartSecondStep";
	}
	
	@PostMapping("/addToDBSecondStep")
	public String addToDbSecondStep(@ModelAttribute CartMetodsDto cartMetodsDto) {
		cartManager.addToDbSecondStep(cartMetodsDto);
		return "redirect:/showCartThirdStepForm";
	}
	
	@GetMapping("/showCartThirdStepForm")
	public String showCartThirdStepForm(Model model, Authentication  authentication) {
		Integer rentalIdFromSession = (Integer) httpSession.getAttribute("rentalID");
		Rental rental=rentalRepo.findById(rentalIdFromSession).get();
		int totalPrice=rentalCost.calculateTotalPrice(rental);
		int totalDeposit=rentalCost.calculateTotalDeposit(rental);
			
		int totalCosts=rentalCost.calculateCosts(totalPrice, totalDeposit);
		model.addAttribute("totalPrice", totalPrice);
		model.addAttribute("totalDeposit", totalDeposit);
		model.addAttribute("totalCosts", totalCosts);
		return "cart/cartThirdStep";
	}
	
	@GetMapping("/showCartFourthStepPage")
	public String showCartFourthStepPage(Model model ) {
		return "cart/cartFourthStep";
	}
	
	@GetMapping("/companyPersonPage")
	public String showCompanyPersonPage(@RequestParam("selectedOption") String selectedOption,Model model,Authentication authentication) {
		User user=userRepo.findById(securityService.getUserFromSession(authentication).getId()).get();
		model.addAttribute("user",user);
		model.addAttribute("personDto", new PersonDto());
		model.addAttribute("companyDto", new CompanyDto());
		model.addAttribute("selectedOption", selectedOption);
		return "cart/companyPersonPage";
	}
	
	
	@PostMapping("/companyPersonPage")
	public String addToDbCompanyOrPerson(@Valid @ModelAttribute PersonDto personDto,BindingResult personBindingResult,@Valid @ModelAttribute CompanyDto companyDto, BindingResult companyBindingResult,
			@RequestParam("selectedOption") String selectedOption,Model model,Authentication authentication,RedirectAttributes redirectAttributes) {
		User user=securityService.getUserFromSession(authentication);
		model.addAttribute("user", user);
		if("person".equals(selectedOption)) {
			if (personBindingResult.hasErrors()) {
				model.addAttribute("selectedOption", selectedOption);
				model.addAttribute("personDto", personDto);
				return"cart/companyPersonPage";
		       }
			cartManager.addToDbFourthStep(personDto, null ,authentication,selectedOption);
		}else if("company".equals(selectedOption)) {
			if(companyBindingResult.hasErrors()) {
				model.addAttribute("selectedOption", selectedOption);
				model.addAttribute("companyDto", companyDto);
				return"cart/companyPersonPage";
			}
			cartManager.addToDbFourthStep(null, companyDto ,authentication,selectedOption);
		}

		return "redirect:/showCartSummary";
	}
	
	@GetMapping("/showCartSummary")
	public String showCartSummary(Model model) {
		return "cart/summary";
	}
	
}
