package com.rental.rentalapplication.DTO;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public class PersonDto {
	
	
	@NotBlank(message="Pole nie może być puste")
	@Size(min=3, message="Imię musi mieć co najmniej 3 znaki")
	private String firstName;
	
	@NotBlank(message="Pole nie może być puste")
	@Size(min=3, message="Nazwisko musi mieć co najmniej 3 znaki")
	private String surname;
	
	@NotEmpty(message="Pole nie może być puste")
	@Size(min=11, max=11, message="Pesel musi posiadać 11 znaków")
	private String pesel;
	
	@NotEmpty(message="Pole nie może być puste")
	@Size(min=9, message="Za krótki numer telefonu")
	private String phoneNumber;
	
	@NotBlank(message="Pole nie może być puste")
	private String place;
	
	@NotBlank(message="Pole nie może być puste")
	private String street;
	
	@NotBlank(message="Pole nie może być puste")
	private String houseNumber;
	
	@NotBlank(message="Pole nie może być puste")
	@Pattern(regexp = "\\d{2}-\\d{3}", message = "Format kodu pocztowego musi być XX-XXX")
	private String zipCode;
	

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}


	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getPlace() {
		return place;
	}

	public void setPlace(String place) {
		this.place = place;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getHouseNumber() {
		return houseNumber;
	}

	public void setHouseNumber(String houseNumber) {
		this.houseNumber = houseNumber;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getPesel() {
		return pesel;
	}

	public void setPesel(String pesel) {
		this.pesel = pesel;
	}

}
