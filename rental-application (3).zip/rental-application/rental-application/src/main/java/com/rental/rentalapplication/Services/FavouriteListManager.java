package com.rental.rentalapplication.Services;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;


import com.rental.rentalapplication.Models.Device;
import com.rental.rentalapplication.Models.DeviceFavouriteList;
import com.rental.rentalapplication.Models.FavouriteList;
import com.rental.rentalapplication.Models.User;
import com.rental.rentalapplication.Repository.DeviceFavouriteListRepository;
import com.rental.rentalapplication.Repository.FavouriteListRepository;
import com.rental.rentalapplication.security.SecurityService;

@Service
public class FavouriteListManager {

	@Autowired
	private SecurityService securityService;
	
	@Autowired
	private FavouriteListRepository favouriteListRepo;
	
	@Autowired
	private DeviceFavouriteListRepository deviceFavouriteListRepo;
	
	@Autowired
	private UserManager userManager;
	
	@Autowired
	private DeviceManager deviceManager;
	
	
	public void addToFavouriteList(Integer id,Authentication authentication) {
		User user= userManager.getUser(securityService.getUserFromSession(authentication).getId());
		FavouriteList favouriteList=user.getFavouriteList();
		Device device=deviceManager.getDevice(id);
		DeviceFavouriteList deviceFavouriteList=new DeviceFavouriteList(device,favouriteList);
		favouriteList.addDeviceFavouriteList(deviceFavouriteList);
		favouriteListRepo.save(favouriteList);
	}
	
	public void deleteDeviceFromFavouriteList(Integer id) {
		DeviceFavouriteList deviceFavouriteList=deviceFavouriteListRepo.findById(id).get();
		deviceFavouriteListRepo.delete(deviceFavouriteList);
	}
}
