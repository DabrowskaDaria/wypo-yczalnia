package com.rental.rentalapplication.validator;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import com.rental.rentalapplication.DTO.DeviceDto;
import com.rental.rentalapplication.Repository.CategoryRepository;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class DeviceDetailsValidator implements ConstraintValidator<ValidDeviceDetails,DeviceDto>{
	
	@Autowired
	private CategoryRepository categoryRepo;
	
	@Override
    public void initialize(ValidDeviceDetails constraintAnnotation) {
    }
	
	@Override
    public boolean isValid(DeviceDto deviceDto, ConstraintValidatorContext context) {
        if (deviceDto == null) {
            return true;
        }

        String category = categoryRepo.findById(deviceDto.getSelectedCategory()).get().getName();
        Map<String, String> deviceDetails = deviceDto.getTechnicalDetails();

        if ("telewizor".equalsIgnoreCase(category)) {
            return validateTV(deviceDetails, context);
        }else if("monitor".equalsIgnoreCase(category)){
            return validateMonitor(deviceDetails, context);
        }else if ("laptop".equalsIgnoreCase(category)){
            return validateLaptop(deviceDetails, context);
        }else if ("nagłośnienie".equalsIgnoreCase(category)){
            return validateAudio(deviceDetails, context);
        }else if ("projektor multimedialny".equalsIgnoreCase(category)){
            return validateProjector(deviceDetails, context);
        }else if ("ekran".equalsIgnoreCase(category)){
            return validateScreen(deviceDetails, context);
        }else if ("oświetlenie".equalsIgnoreCase(category)){
            return validateLighting(deviceDetails, context);
        }else if ("słuchawki".equalsIgnoreCase(category)){
            return validateHeadphone(deviceDetails, context);
        }else if ("tablet".equalsIgnoreCase(category)){
            return validateTablet(deviceDetails, context);
        }else if ("Kamera".equalsIgnoreCase(category)){
            return validateCamera(deviceDetails, context);
        }else if ("Mikrofon".equalsIgnoreCase(category)){
            return validateMicrophone(deviceDetails, context);
        }

        return true;
    }

    private boolean validateTV(Map<String, String> deviceDetails, ConstraintValidatorContext context) {
        boolean isValid = true;

        String screenSize = deviceDetails.get("screenSize");
        if (screenSize == null || screenSize.isEmpty()) {
            context.disableDefaultConstraintViolation();
            context.buildConstraintViolationWithTemplate("Pole rozmiar ekranu jest wymagane")
                   .addPropertyNode("screenSize")
                   .addConstraintViolation();
            isValid = false;
        }  
        String screenResolution = deviceDetails.get("screenResolution");
        if(screenResolution==null || screenResolution.isEmpty()){
        	context.disableDefaultConstraintViolation();
            context.buildConstraintViolationWithTemplate("Pole rozdzielczość jest wymagane")
                   .addPropertyNode("screenResolution")
                   .addConstraintViolation();
            isValid = false;
        }
        
        String refreshRate = deviceDetails.get("refreshRate");
        if(refreshRate==null || refreshRate.isEmpty()){
        	context.disableDefaultConstraintViolation();
            context.buildConstraintViolationWithTemplate("Pole częstotliwość odświerzania jest wymagane")
                   .addPropertyNode("refreshRate")
                   .addConstraintViolation();
            isValid = false;
        }

        return isValid;
    }
    
    
    private boolean validateMonitor(Map<String, String> deviceDetails, ConstraintValidatorContext context) {
        boolean isValid = true;

        
       
        String screenSize = deviceDetails.get("screenSize");
        if (screenSize == null || screenSize.isEmpty()) {
            context.disableDefaultConstraintViolation();
            context.buildConstraintViolationWithTemplate("Pole rozmiar ekranu jest wymagane")
                   .addPropertyNode("screenSize")
                   .addConstraintViolation();
            isValid = false;
        }  
        String screenResolution = deviceDetails.get("screenResolution");
        if(screenResolution==null || screenResolution.isEmpty()){
        	context.disableDefaultConstraintViolation();
            context.buildConstraintViolationWithTemplate("Pole rozdzielczość jest wymagane")
                   .addPropertyNode("screenResolution")
                   .addConstraintViolation();
            isValid = false;
        }
        
        String refreshRate = deviceDetails.get("refreshRate");
        if(refreshRate==null || refreshRate.isEmpty()){
        	context.disableDefaultConstraintViolation();
            context.buildConstraintViolationWithTemplate("Pole częstotliwość odświerzania jest wymagane")
                   .addPropertyNode("refreshRate")
                   .addConstraintViolation();
            isValid = false;
        }

        return isValid;
    }
    
    private boolean validateLaptop(Map<String, String> deviceDetails, ConstraintValidatorContext context) {
        boolean isValid = true;

        
       
        String display = deviceDetails.get("display");
        if (display == null || display.isEmpty()) {
            context.disableDefaultConstraintViolation();
            context.buildConstraintViolationWithTemplate("Pole jest wymagane")
                   .addPropertyNode("display")
                   .addConstraintViolation();
            isValid = false;
        }  
        String processor = deviceDetails.get("processor");
        if(processor==null || processor.isEmpty()){
        	context.disableDefaultConstraintViolation();
            context.buildConstraintViolationWithTemplate("Pole jest wymagane")
                   .addPropertyNode("processor")
                   .addConstraintViolation();
            isValid = false;
        }
        
        String drive = deviceDetails.get("drive");
        if(drive==null || drive.isEmpty()){
        	context.disableDefaultConstraintViolation();
            context.buildConstraintViolationWithTemplate("Pole jest wymagane")
                   .addPropertyNode("drive")
                   .addConstraintViolation();
            isValid = false;
        }
        
        String graphicsCard = deviceDetails.get("graphicsCard");
        if(graphicsCard==null || graphicsCard.isEmpty()){
        	context.disableDefaultConstraintViolation();
            context.buildConstraintViolationWithTemplate("Pole jest wymagane")
                   .addPropertyNode("graphicsCard")
                   .addConstraintViolation();
            isValid = false;
        }
        

        return isValid;
    }
    
    
    private boolean validateAudio(Map<String, String> deviceDetails, ConstraintValidatorContext context) {
        boolean isValid = true;

        
       
        String speakersPower = deviceDetails.get("speakersPower");
        if (speakersPower == null || speakersPower.isEmpty()) {
            context.disableDefaultConstraintViolation();
            context.buildConstraintViolationWithTemplate("Pole jest wymagane")
                   .addPropertyNode("speakersPower")
                   .addConstraintViolation();
            isValid = false;
        }  
        String numberOfspeakers = deviceDetails.get("numberOfspeakers");
        if(numberOfspeakers==null || numberOfspeakers.isEmpty()){
        	context.disableDefaultConstraintViolation();
            context.buildConstraintViolationWithTemplate("Pole jest wymagane")
                   .addPropertyNode("numberOfspeakers")
                   .addConstraintViolation();
            isValid = false;
        }

        return isValid;
    }
    
    private boolean validateProjector(Map<String, String> deviceDetails, ConstraintValidatorContext context) {
        boolean isValid = true;


        String lampPower = deviceDetails.get("lampPower");
        if(lampPower==null || lampPower.isEmpty()){
        	context.disableDefaultConstraintViolation();
            context.buildConstraintViolationWithTemplate("Pole jest wymagane")
                   .addPropertyNode("lampPower")
                   .addConstraintViolation();
            isValid = false;
        }
        
        String screenResolution = deviceDetails.get("screenResolution");
        if(screenResolution==null || screenResolution.isEmpty()){
        	context.disableDefaultConstraintViolation();
            context.buildConstraintViolationWithTemplate("Pole jest wymagane")
                   .addPropertyNode("screenResolution")
                   .addConstraintViolation();
            isValid = false;
        }
        

        return isValid;
    }
    
    private boolean validateScreen(Map<String, String> deviceDetails, ConstraintValidatorContext context) {
        boolean isValid = true;

        String screenFormat = deviceDetails.get("screenFormat");
        if (screenFormat == null || screenFormat.isEmpty()) {
            context.disableDefaultConstraintViolation();
            context.buildConstraintViolationWithTemplate("Pole jest wymagane")
                   .addPropertyNode("screenFormat")
                   .addConstraintViolation();
            isValid = false;
        }  
        String screenSize = deviceDetails.get("screenSize");
        if(screenSize==null || screenSize.isEmpty()){
        	context.disableDefaultConstraintViolation();
            context.buildConstraintViolationWithTemplate("Pole jest wymagane")
                   .addPropertyNode("screenSize")
                   .addConstraintViolation();
            isValid = false;
        }
        
        String activeSurface = deviceDetails.get("activeSurface");
        if(activeSurface==null || activeSurface.isEmpty()){
        	context.disableDefaultConstraintViolation();
            context.buildConstraintViolationWithTemplate("Pole jest wymagane")
                   .addPropertyNode("activeSurface")
                   .addConstraintViolation();
            isValid = false;
        }
        
        return isValid;
    }
    
    private boolean validateLighting(Map<String, String> deviceDetails, ConstraintValidatorContext context) {
        boolean isValid = true;

        String lightingColor = deviceDetails.get("lightingColor");
        if (lightingColor == null || lightingColor.isEmpty()) {
            context.disableDefaultConstraintViolation();
            context.buildConstraintViolationWithTemplate("Pole jest wymagane")
                   .addPropertyNode("lightingColor")
                   .addConstraintViolation();
            isValid = false;
        }  
        String powerConsumption = deviceDetails.get("powerConsumption");
        if(powerConsumption==null || powerConsumption.isEmpty()){
        	context.disableDefaultConstraintViolation();
            context.buildConstraintViolationWithTemplate("Pole jest wymagane")
                   .addPropertyNode("powerConsumption")
                   .addConstraintViolation();
            isValid = false;
        }
        
        String deviceSize = deviceDetails.get("deviceSize");
        if(deviceSize==null || deviceSize.isEmpty()){
        	context.disableDefaultConstraintViolation();
            context.buildConstraintViolationWithTemplate("Pole jest wymagane")
                   .addPropertyNode("deviceSize")
                   .addConstraintViolation();
            isValid = false;
        }
        
        String lampPower = deviceDetails.get("lampPower");
        if(lampPower==null || lampPower.isEmpty()){
        	context.disableDefaultConstraintViolation();
            context.buildConstraintViolationWithTemplate("Pole jest wymagane")
                   .addPropertyNode("lampPower")
                   .addConstraintViolation();
            isValid = false;
        }
        return isValid;
    }
    
    private boolean validateHeadphone(Map<String, String> deviceDetails, ConstraintValidatorContext context) {
        boolean isValid = true;

        
        String workingTime = deviceDetails.get("workingTime");
        if(workingTime==null || workingTime.isEmpty()){
        	context.disableDefaultConstraintViolation();
            context.buildConstraintViolationWithTemplate("Pole jest wymagane")
                   .addPropertyNode("workingTime")
                   .addConstraintViolation();
            isValid = false;
        }
        return isValid;
    }
    
    private boolean validateTablet(Map<String, String> deviceDetails, ConstraintValidatorContext context) {
        boolean isValid = true;

        String display = deviceDetails.get("display");
        if (display == null || display.isEmpty()) {
            context.disableDefaultConstraintViolation();
            context.buildConstraintViolationWithTemplate("Pole jest wymagane")
                   .addPropertyNode("display")
                   .addConstraintViolation();
            isValid = false;
        }  
        String processor = deviceDetails.get("processor");
        if(processor==null || processor.isEmpty()){
        	context.disableDefaultConstraintViolation();
            context.buildConstraintViolationWithTemplate("Pole jest wymagane")
                   .addPropertyNode("processor")
                   .addConstraintViolation();
            isValid = false;
        }
        
        String drive = deviceDetails.get("drive");
        if(drive==null || drive.isEmpty()){
        	context.disableDefaultConstraintViolation();
            context.buildConstraintViolationWithTemplate("Pole jest wymagane")
                   .addPropertyNode("drive")
                   .addConstraintViolation();
            isValid = false;
        }
        

        return isValid;
    }
    
    private boolean validateCamera(Map<String, String> deviceDetails, ConstraintValidatorContext context) {
        boolean isValid = true;

        String resolution = deviceDetails.get("resolution");
        if (resolution == null || resolution.isEmpty()) {
            context.disableDefaultConstraintViolation();
            context.buildConstraintViolationWithTemplate("Pole jest wymagane")
                   .addPropertyNode("resolution")
                   .addConstraintViolation();
            isValid = false;
        }
        
        return isValid;
    }
    
    private boolean validateMicrophone(Map<String, String> deviceDetails, ConstraintValidatorContext context) {
        boolean isValid = true;
 
        String frequencyResponse = deviceDetails.get("frequencyResponse");
        if(frequencyResponse==null || frequencyResponse.isEmpty()){
        	context.disableDefaultConstraintViolation();
            context.buildConstraintViolationWithTemplate("Pole jest wymagane")
                   .addPropertyNode("frequencyResponse")
                   .addConstraintViolation();
            isValid = false;
        }
        
        return isValid;
    }
}
