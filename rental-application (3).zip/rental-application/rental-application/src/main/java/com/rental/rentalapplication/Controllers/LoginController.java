package com.rental.rentalapplication.Controllers;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;


@Controller
public class LoginController {
	
	@GetMapping("/login")
	public String showLoginForm(Model model,@RequestParam(name = "error", required = false) String error) {
		if (error != null) {
			model.addAttribute("message", "Nieprawidłowy email lub hasło.");
		}
		return"/login/login";
	}


}
