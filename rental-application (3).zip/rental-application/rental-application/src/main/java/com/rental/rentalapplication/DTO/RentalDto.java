package com.rental.rentalapplication.DTO;

import java.time.LocalDate;

import com.rental.rentalapplication.Models.RentalStatus;
import com.rental.rentalapplication.Models.User;

public class RentalDto {
	
	private User user;
	
	private LocalDate rentalStartDate;
	
	private LocalDate rentalEndDate;
	
	private RentalStatus rentalStatus;

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public LocalDate getRentalStartDate() {
		return rentalStartDate;
	}

	public void setRentalStartDate(LocalDate rentalStartDate) {
		this.rentalStartDate = rentalStartDate;
	}

	public LocalDate getRentalEndDate() {
		return rentalEndDate;
	}

	public void setRentalEndDate(LocalDate rentalEndDate) {
		this.rentalEndDate = rentalEndDate;
	}

	public RentalStatus getRentalStatus() {
		return rentalStatus;
	}

	public void setRentalStatus(RentalStatus rentalStatus) {
		this.rentalStatus = rentalStatus;
	}

	
}
