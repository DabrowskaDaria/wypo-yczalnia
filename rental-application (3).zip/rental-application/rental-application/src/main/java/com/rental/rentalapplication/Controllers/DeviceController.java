package com.rental.rentalapplication.Controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.rental.rentalapplication.DTO.CartDataDto;
import com.rental.rentalapplication.DTO.CompanyDto;
import com.rental.rentalapplication.DTO.DeviceDto;
import com.rental.rentalapplication.DTO.PersonDto;
import com.rental.rentalapplication.Models.Category;

import com.rental.rentalapplication.Models.Connector;
import com.rental.rentalapplication.Models.Device;
import com.rental.rentalapplication.Models.User;
import com.rental.rentalapplication.Repository.DeviceRepository;
import com.rental.rentalapplication.Services.CategoryManager;
import com.rental.rentalapplication.Services.ConnectorManager;
import com.rental.rentalapplication.Services.DeviceManager;

import jakarta.validation.Valid;

@Controller
@RequestMapping("/device")
public class DeviceController {
	@Autowired
	private DeviceManager deviceManager;
	
	@Autowired
	private CategoryManager categoryManager;
	
	@Autowired
	private ConnectorManager connectorManager;
	
	
	@GetMapping("/showCategories")
    public String showCategories(Model model) {
        List<Category> categories = categoryManager.showCategory();
        model.addAttribute("categories", categories);
        return "device/chooseCategory";
    }
	
	@GetMapping("/showAddDevice")
    public String showDeviceAddForm(@RequestParam("selectedCategory") Integer selectedCategory, Model model) {
        List<Connector> connectors = connectorManager.showConnectors();
        DeviceDto deviceDto= new DeviceDto();
        deviceDto.setSelectedCategory(selectedCategory);
        model.addAttribute("deviceDto",deviceDto);
        model.addAttribute("selectedCategory", selectedCategory);
        model.addAttribute("connectors", connectors);
        return "device/addDevice";
    }
	
	@PostMapping("/add")
    public String addDevice(@Validated(DeviceDto.Add.class) @ModelAttribute DeviceDto deviceDto,BindingResult bindingResult,@RequestParam("selectedCategory") Integer selectedCategory,Model model, RedirectAttributes redirectAttributes) {
		
		if (bindingResult.hasErrors()) {
			model.addAttribute("deviceDto",deviceDto);
			List<Connector> connectors = connectorManager.showConnectors();
			model.addAttribute("connectors", connectors);
			model.addAttribute("selectedCategory", selectedCategory);
            return "device/addDevice";
        }
		
		try {
            deviceManager.addDevice(selectedCategory,deviceDto);
            redirectAttributes.addFlashAttribute("info", "Dodano urządzenie");
        } catch (Exception ex) {
            redirectAttributes.addFlashAttribute("info", "Nie dodano urządzenia");
        }
        return "redirect:/device/showAddDevice?selectedCategory=" + selectedCategory;
    }
	
	@GetMapping("/showDevices")
	public String showDevices(Model model) {
		List <Device> devices=deviceManager.showDevices();
		model.addAttribute("devices", devices);
		return "device/showDevices";
	}
	
	@PostMapping("/deleteDevice/{id}/delete")
	public String deleteDevice(@PathVariable("id") Integer id) {
		deviceManager.deleteDevice(id);
		return"redirect:/device/showDevices";
	}
	
	@GetMapping("/modify/{id}")
	public String showModifyDeviceForm(@PathVariable ("id") Integer id, Model model) {
		
		Device device=deviceManager.getDevice(id);
		DeviceDto deviceDto= new DeviceDto();
        deviceDto.setSelectedCategory(device.getCategory().getId());
        
		model.addAttribute("device", device);
		model.addAttribute("deviceDto", deviceDto);
		return "device/modifyDevice";
	}
	
	@PostMapping("/modify/{id}")
	public String modifyDevice(@PathVariable ("id") Integer id,@Validated(DeviceDto.Modify.class) @ModelAttribute  DeviceDto deviceDto,BindingResult bindingResult,Model model) {
		
		if (bindingResult.hasErrors()) {
			for (ObjectError error : bindingResult.getAllErrors()) {
	            System.out.println(error.getDefaultMessage());
	        }
			System.out.println("wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww");
	        model.addAttribute("device", deviceManager.getDevice(id));
	        
            return "device/modifyDevice";
        }
        
		deviceManager.modify(deviceDto, id);
		return "redirect:/device/showDevices";
	}
	
	
	
}
