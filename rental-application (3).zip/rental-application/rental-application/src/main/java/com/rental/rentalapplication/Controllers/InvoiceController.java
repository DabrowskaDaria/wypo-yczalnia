package com.rental.rentalapplication.Controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.rental.rentalapplication.RentalCost;
import com.rental.rentalapplication.Models.Device;
import com.rental.rentalapplication.Models.Invoice;
import com.rental.rentalapplication.Repository.InvoiceRepository;
import com.rental.rentalapplication.Services.InvoiceManager;

@Controller
public class InvoiceController {

	@Autowired
	private InvoiceRepository invoiceRepo;
	
	@Autowired
	private RentalCost rentalCost;
	
	@Autowired
	private InvoiceManager invoiceManager;
	
	@GetMapping("/showInvoices")
	public String showInvoices(Model model) {
		List<Invoice> invoices= invoiceRepo.findAll();
		model.addAttribute("invoices", invoices);
		return "/invoice/showInvoices";
	}
	
	@GetMapping("/showInvoicesDetails/{id}")
	public String showInvoicesDetails(@PathVariable Integer id, Model model) {
		Invoice invoice=invoiceRepo.findById(id).get();
		List<Device> devices=invoiceManager.getDeviceFromInvoice(invoice);
		Integer price= rentalCost.calculateTotalPrice(invoice.getRental());
		Integer deposit= rentalCost.calculateTotalDeposit(invoice.getRental());
		Integer totalCost=rentalCost.calculateCosts(price, deposit);
		model.addAttribute("devices", devices);
		model.addAttribute("costs", totalCost);
		model.addAttribute("idInvoice", id);
		if(invoice.getRental().getUser().getCompany()!=null) {
			model.addAttribute("company", invoice.getRental().getUser().getCompany());
		}else {
			model.addAttribute("person", invoice.getRental().getUser().getPerson());
		}
		model.addAttribute("payment", invoice.getRental().getMethodOfPayment());
		model.addAttribute("invoiceDate", invoice.getInvoiceDate());
		return "/invoice/invoiceDetails";
	}
}
