package com.rental.rentalapplication.DTO;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public class CompanyDto {
	@NotBlank(message="Pole nie może być puste")
	private String place;
	
	@NotBlank(message="Pole nie może być puste")
	private String street;
	
	@NotBlank(message="Pole nie może być puste")
	@Pattern(regexp = "\\d{2}-\\d{3}", message = "Format kodu pocztowego musi być XX-XXX")
	private String zipCode;
	
	@NotBlank(message="Pole nie może być puste")
	@Size(min=3, message="Nazwa musi mieć co najmniej 3 znaki")
	private String name;
	
	@NotBlank(message="Pole nie może być puste")
	@Size(min=10, message="Za krótki nip")
	private String companyNumber;
	
	@NotEmpty(message="Pole nie może być puste")
	private String buldingNumber;

	public String getPlace() {
		return place;
	}

	public void setPlace(String place) {
		this.place = place;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCompanyNumber() {
		return companyNumber;
	}

	public void setCompanyNumber(String companyNumber) {
		this.companyNumber = companyNumber;
	}

	public String getBuldingNumber() {
		return buldingNumber;
	}

	public void setBuldingNumber(String buldingNumber) {
		this.buldingNumber = buldingNumber;
	}
}
