package com.rental.rentalapplication.Services;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rental.rentalapplication.RentalCost;
import com.rental.rentalapplication.Models.Invoice;
import com.rental.rentalapplication.Models.InvoiceType;
import com.rental.rentalapplication.Models.Rental;
import com.rental.rentalapplication.Repository.InvoiceRepository;

@Service
public class InvoiceGenerator {
	
	@Autowired
	private RentalCost rentalCost;
	
	@Autowired
	private InvoiceRepository invoiceRepo;
	
	public void generateInvoice(Rental rental, InvoiceType invoiceType,LocalDate now) {
		Integer totalPrice=rentalCost.calculateTotalPrice(rental);
		Integer totalDeposit=rentalCost.calculateTotalDeposit(rental);
		Invoice invoice=new Invoice(now, totalPrice, totalDeposit, invoiceType, rental);
		invoiceRepo.save(invoice);
	}
}
