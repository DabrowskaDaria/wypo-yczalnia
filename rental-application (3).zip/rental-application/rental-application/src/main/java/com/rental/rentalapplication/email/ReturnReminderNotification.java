package com.rental.rentalapplication.email;

import java.time.LocalDate;

import com.rental.rentalapplication.Models.Rental;
import com.rental.rentalapplication.Models.User;

public class ReturnReminderNotification extends EmailMessage {

	private Rental rental;
	public ReturnReminderNotification(User receiver, Rental rental) {
		super(receiver);
		this.rental=rental;
	}

	@Override
	public String content() {
		return "Przypominamy o zwrocie wypożyczenia o numerze "+rental.getId()+" Urządzenia należy zwrocić dnia "+rental.getRentalEndDate()+" .";
	}

	@Override
	public String subject() {
		return "Przypomnienie zwrotu";
	}

}
